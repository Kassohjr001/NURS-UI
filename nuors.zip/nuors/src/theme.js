// Central theme tokens. Each role keeps the color identity from the original
// dashboard prototype so the routed pages stay visually consistent with it.

export const ROLES = {
  student: 'student',
  audit: 'audit',
  finance: 'finance',
  exams: 'exams',
  hod: 'hod',
  dean: 'dean',
  registrar: 'registrar',
  admin: 'admin',
  vc: 'vc'
}

export const THEME = {
  student: {
    label: 'Student Portal',
    office: 'Student Dashboard',
    primary: '#0f5e59',
    primaryDark: '#0a3d3a',
    accent: '#14b8a6',
    soft: '#e6f7f5'
  },
  audit: {
    label: 'Audit Department',
    office: 'Audit Dashboard',
    primary: '#16315c',
    primaryDark: '#0c1d3a',
    accent: '#3b82f6',
    soft: '#e8edfb'
  },
  finance: {
    label: 'Finance Office',
    office: 'Finance Dashboard',
    primary: '#0f5132',
    primaryDark: '#0a3a23',
    accent: '#22c55e',
    soft: '#e7f8ee'
  },
  exams: {
    label: 'Examinations Dept.',
    office: 'Exams Office Dashboard',
    primary: '#4c1d95',
    primaryDark: '#33126b',
    accent: '#a855f7',
    soft: '#f1e9fb'
  },
  hod: {
    label: 'Head of Department',
    office: 'HOD Dashboard',
    primary: '#7c4a03',
    primaryDark: '#5c3702',
    accent: '#f59e0b',
    soft: '#fbf0dd'
  },
  dean: {
    label: "Dean's Office",
    office: 'Dean Dashboard',
    primary: '#7f1d1d',
    primaryDark: '#5c1313',
    accent: '#ef4444',
    soft: '#fbe9e9'
  },
  registrar: {
    label: 'Department Registrar',
    office: 'Department Registrar Dashboard',
    primary: '#0f766e',
    primaryDark: '#0a4f49',
    accent: '#2dd4bf',
    soft: '#e3f6f4'
  },
  admin: {
    label: 'System Administrator',
    office: 'System Admin Dashboard',
    primary: '#0f172a',
    primaryDark: '#070b14',
    accent: '#38bdf8',
    soft: '#e6f0fa'
  },
  vc: {
    label: "Vice Chancellor's Office",
    office: 'Vice Chancellor Dashboard',
    primary: '#1e3a8a',
    primaryDark: '#142a63',
    accent: '#60a5fa',
    soft: '#e8effc'
  }
}

export const ROLE_HOME = {
  student: '/',
  audit: '/audit',
  finance: '/finance',
  exams: '/exams',
  hod: '/hod',
  dean: '/dean',
  registrar: '/registrar',
  admin: '/admin',
  vc: '/vc'
}

export const ROLE_LOGIN = '/login'
