import { Routes, Route, Navigate } from 'react-router-dom'

import LoginPage from './components/auth/LoginPage.jsx'
import ChangePasswordPage from './components/auth/ChangePasswordPage.jsx'
import ProtectedRoute from './components/common/ProtectedRoute.jsx'

import StudentDashboard from './components/student/StudentDashboard.jsx'
import AuditDashboard from './components/audit/AuditDashboard.jsx'
import FinanceDashboard from './components/finance/FinanceDashboard.jsx'
import ExamsDashboard from './components/exams/ExamsDashboard.jsx'
import HodDashboard from './components/hod/HodDashboard.jsx'
import DeanDashboard from './components/dean/DeanDashboard.jsx'
import RegistrarDashboard from './components/registrar/RegistrarDashboard.jsx'
import AdminDashboard from './components/admin/AdminDashboard.jsx'
import VcDashboard from './components/vc/VcDashboard.jsx'

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/change-password" element={<ChangePasswordPage />} />

      <Route
        path="/"
        element={
          <ProtectedRoute role="student">
            <StudentDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/audit"
        element={
          <ProtectedRoute role="audit">
            <AuditDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/finance"
        element={
          <ProtectedRoute role="finance">
            <FinanceDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/exams"
        element={
          <ProtectedRoute role="exams">
            <ExamsDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/hod"
        element={
          <ProtectedRoute role="hod">
            <HodDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/dean"
        element={
          <ProtectedRoute role="dean">
            <DeanDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/registrar"
        element={
          <ProtectedRoute role="registrar">
            <RegistrarDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin"
        element={
          <ProtectedRoute role="admin">
            <AdminDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/vc"
        element={
          <ProtectedRoute role="vc">
            <VcDashboard />
          </ProtectedRoute>
        }
      />

      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  )
}
