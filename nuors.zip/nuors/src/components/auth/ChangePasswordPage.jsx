import { useState } from 'react'
import { useNavigate, Navigate } from 'react-router-dom'
import { Check, X, ShieldCheck } from 'lucide-react'
import { useAuth } from '../../context/AuthContext.jsx'
import { useDataStore } from '../../context/DataStoreContext.jsx'
import { ROLE_HOME, THEME } from '../../theme.js'

function Rule({ met, label }) {
  return (
    <div className={`flex items-center gap-2 text-xs ${met ? 'text-green-600' : 'text-gray-400'}`}>
      {met ? <Check size={13} /> : <X size={13} />}
      <span>{label}</span>
    </div>
  )
}

export default function ChangePasswordPage() {
  const { user, clearMustChangePassword } = useAuth()
  const store = useDataStore()
  const navigate = useNavigate()

  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState('')

  const rules = {
    length: next.length >= 8,
    upper: /[A-Z]/.test(next),
    lower: /[a-z]/.test(next),
    number: /[0-9]/.test(next),
    notDefault: next.length > 0 && next !== 'Welcome123'
  }
  const allRulesMet = Object.values(rules).every(Boolean)
  const matches = next.length > 0 && next === confirm

  const handleSubmit = (e) => {
    e.preventDefault()
    const account = store.getAccount(user.idNumber)

    if (!account) {
      setError('Could not find your account. Please sign in again.')
      return
    }
    if (account.password !== current) {
      setError('Your current password is incorrect.')
      return
    }
    if (!allRulesMet) {
      setError('Your new password does not meet the requirements below yet.')
      return
    }
    if (!matches) {
      setError('New password and confirmation do not match.')
      return
    }

    store.updateAccountPassword(account.idNumber, next)
    clearMustChangePassword()
    navigate(ROLE_HOME[user.role])
  }

  if (!user) return <Navigate to="/login" replace />

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden">
        <div
          className="px-8 py-7 text-white"
          style={{ background: `linear-gradient(135deg, ${THEME.admin.primary}, ${THEME.admin.primaryDark})` }}
        >
          <div className="w-11 h-11 rounded-lg bg-white/15 flex items-center justify-center mb-3">
            <ShieldCheck size={20} />
          </div>
          <h1 className="font-display font-bold text-xl">Set a Trusted Password</h1>
          <p className="text-white/70 text-sm mt-1">
            Welcome, {user.name}. Your account was created with a temporary password — choose one only you know
            before continuing.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="px-8 py-7 space-y-4">
          {error && (
            <div className="text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2.5">{error}</div>
          )}

          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1.5">Current (temporary) password</label>
            <input
              required
              type="password"
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
              placeholder="Welcome123"
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1.5">New password</label>
            <input
              required
              type="password"
              value={next}
              onChange={(e) => setNext(e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1.5">Confirm new password</label>
            <input
              required
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2"
            />
            {confirm.length > 0 && !matches && (
              <p className="text-[11px] text-red-500 mt-1">Passwords don't match yet.</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-1.5 bg-gray-50 rounded-lg p-3">
            <Rule met={rules.length} label="At least 8 characters" />
            <Rule met={rules.upper} label="One uppercase letter" />
            <Rule met={rules.lower} label="One lowercase letter" />
            <Rule met={rules.number} label="One number" />
            <Rule met={rules.notDefault} label="Not the temporary password" />
          </div>

          <button
            type="submit"
            disabled={!allRulesMet || !matches}
            className="w-full flex items-center justify-center gap-2 bg-gray-900 disabled:bg-gray-300 text-white font-semibold text-sm py-2.5 rounded-lg"
          >
            Save Password & Continue
          </button>
        </form>
      </div>
    </div>
  )
}
