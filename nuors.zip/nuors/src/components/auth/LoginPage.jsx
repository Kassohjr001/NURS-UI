import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { LogIn, AlertCircle, ShieldCheck } from 'lucide-react'
import { useAuth } from '../../context/AuthContext.jsx'
import { useDataStore } from '../../context/DataStoreContext.jsx'
import { ROLE_HOME, THEME } from '../../theme.js'

export default function LoginPage() {
  const { login } = useAuth()
  const store = useDataStore()
  const navigate = useNavigate()

  const [idNumber, setIdNumber] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')

  const proceed = (account) => {
    login(account)
    if (account.mustChangePassword) {
      navigate('/change-password')
    } else {
      navigate(ROLE_HOME[account.role])
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const account = store.getAccount(idNumber.trim())

    if (!account) {
      setError('No account found for that ID. Every account is created by the System Admin — ask them to set one up for you.')
      return
    }
    if (account.status === 'Suspended') {
      setError('This account has been suspended. Contact the System Admin.')
      return
    }
    if (account.password !== password) {
      setError('Incorrect password.')
      return
    }
    setError('')
    proceed(account)
  }

  const quickLogin = (account) => {
    setError('')
    proceed(account)
  }

  const seenRoles = new Set()
  const quickAccounts = store.accounts.filter((a) => {
    if (seenRoles.has(a.role)) return false
    seenRoles.add(a.role)
    return true
  })

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden">
        <div
          className="px-8 py-7 text-white"
          style={{ background: `linear-gradient(135deg, ${THEME.student.primary}, ${THEME.admin.primary})` }}
        >
          <div className="w-11 h-11 rounded-lg bg-white/15 flex items-center justify-center font-display font-bold mb-3">
            NU
          </div>
          <h1 className="font-display font-bold text-xl">NUORS Sign In</h1>
          <p className="text-white/70 text-sm mt-1">
            One login for every office — your account decides which dashboard you land on.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="px-8 py-7 space-y-4">
          {error && (
            <div className="flex items-start gap-2 text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2.5">
              <AlertCircle size={15} className="shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1.5">Student / Staff ID</label>
            <input
              required
              value={idNumber}
              onChange={(e) => setIdNumber(e.target.value)}
              placeholder="e.g. NU/CSC/2020/001 or STAFF-AUD-01"
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1.5">Password</label>
            <input
              required
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2"
            />
          </div>

          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 bg-gray-900 text-white font-semibold text-sm py-2.5 rounded-lg mt-2"
          >
            <LogIn size={16} />
            Sign in
          </button>

          <div className="flex items-start gap-2 text-[11px] text-gray-400 pt-1">
            <ShieldCheck size={14} className="shrink-0 mt-0.5" />
            <span>
              No account exists until the System Admin creates one for you. New accounts use the temporary
              password <span className="font-mono font-semibold text-gray-500">Welcome123</span> and you'll be asked
              to set your own on first sign-in.
            </span>
          </div>
        </form>

        <div className="px-8 pb-7 -mt-2">
          <p className="text-xs font-semibold text-gray-400 mb-2">Quick demo login (skips password)</p>
          <div className="flex flex-wrap gap-1.5">
            {quickAccounts.map((a) => (
              <button
                key={a.id}
                onClick={() => quickLogin(a)}
                className="text-[11px] px-2.5 py-1 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 capitalize"
              >
                {a.role}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
