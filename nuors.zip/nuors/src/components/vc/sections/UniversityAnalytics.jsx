import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { DEPARTMENTS } from '../../../data/mockData.js'

export default function UniversityAnalytics() {
  return (
    <Card title="University Analytics">
      <DataTable
        columns={[{ key: 'name', label: 'Department' }, { key: 'students', label: 'Students' }]}
        rows={DEPARTMENTS.map((d) => ({ name: d.name, students: d.students }))}
      />
    </Card>
  )
}
