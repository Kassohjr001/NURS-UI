import Card from '../../common/Card.jsx'

export default function Reports({ students, totalRevenue, registrationRate }) {
  return (
    <Card title="Reports">
      <p className="text-sm text-gray-500">
        Students: {students.length} · Revenue: Le {totalRevenue.toLocaleString()} · Registration Rate: {registrationRate}%
      </p>
    </Card>
  )
}
