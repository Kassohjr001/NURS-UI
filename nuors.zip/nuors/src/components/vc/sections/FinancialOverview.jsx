import Card from '../../common/Card.jsx'
import { MiniPieChart, PieLegend } from '../../common/Charts.jsx'

export default function FinancialOverview({ totalRevenue }) {
  const revenueSplit = [
    { name: 'Tuition Fees', value: Math.round(totalRevenue * 0.8) },
    { name: 'Other Fees', value: Math.round(totalRevenue * 0.15) },
    { name: 'Other Income', value: Math.round(totalRevenue * 0.05) }
  ]
  return (
    <Card title="Financial Overview">
      <p className="text-sm text-gray-600 mb-3">Total revenue collected this semester: Le {totalRevenue.toLocaleString()}</p>
      <MiniPieChart data={revenueSplit} />
      <PieLegend data={revenueSplit} />
    </Card>
  )
}
