import StatCard from '../../common/StatCard.jsx'
import Card from '../../common/Card.jsx'
import { MiniLineChart, MiniPieChart, PieLegend, MiniBarChart } from '../../common/Charts.jsx'
import { DEPARTMENTS } from '../../../data/mockData.js'
import { THEME } from '../../../theme.js'

export default function Overview({ students, totalRevenue, registrationRate }) {
  const enrollmentTrend = [
    { name: 'Feb', value: 14200 }, { name: 'Mar', value: 14600 }, { name: 'Apr', value: 14950 },
    { name: 'May', value: 15080 }, { name: 'Jun', value: 15230 }
  ]
  const revenueSplit = [
    { name: 'Tuition Fees', value: Math.round(totalRevenue * 0.8) },
    { name: 'Other Fees', value: Math.round(totalRevenue * 0.15) },
    { name: 'Other Income', value: Math.round(totalRevenue * 0.05) }
  ]
  const facultyPerformance = DEPARTMENTS.map((d) => ({ name: d.name, value: d.students }))
  const topDepartments = [...DEPARTMENTS].sort((a, b) => b.students - a.students)

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Students" value={students.length} icon="users" color={THEME.vc.accent} />
        <StatCard label="Total Revenue" value={`Le ${totalRevenue.toLocaleString()}`} icon="revenue" color="#22c55e" />
        <StatCard label="Registration Rate" value={`${registrationRate}%`} icon="approved" color="#a855f7" />
        <StatCard label="Pass Rate" value="92%" icon="chart" color="#f59e0b" />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <Card title="Student Enrollment Trend">
          <MiniLineChart data={enrollmentTrend} color={THEME.vc.accent} />
        </Card>
        <Card title="Revenue Overview">
          <MiniPieChart data={revenueSplit} />
          <PieLegend data={revenueSplit} />
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <Card title="Faculty Performance (students)">
          <MiniBarChart data={facultyPerformance} color={THEME.vc.accent} />
        </Card>
        <Card title="Top Performing Departments">
          <ol className="space-y-2 text-sm text-gray-600 list-decimal list-inside">
            {topDepartments.map((d) => (
              <li key={d.name}>{d.name} — {d.students} students</li>
            ))}
          </ol>
        </Card>
      </div>
    </div>
  )
}
