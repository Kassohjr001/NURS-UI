import Card from '../../common/Card.jsx'

export default function AcademicOverview({ fullyRegistered, totalForms, registrationRate }) {
  return (
    <Card title="Academic Overview">
      <p className="text-sm text-gray-600">
        {fullyRegistered} of {totalForms} submitted registration forms are fully signed off this
        semester ({registrationRate}%).
      </p>
    </Card>
  )
}
