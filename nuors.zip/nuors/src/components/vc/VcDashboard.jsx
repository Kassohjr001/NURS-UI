import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import DashboardShell from '../layout/DashboardShell.jsx'
import { useAuth } from '../../context/AuthContext.jsx'
import { useDataStore, STAGE_ORDER } from '../../context/DataStoreContext.jsx'
import { THEME } from '../../theme.js'

import Overview from './sections/Overview.jsx'
import UniversityAnalytics from './sections/UniversityAnalytics.jsx'
import FinancialOverview from './sections/FinancialOverview.jsx'
import AcademicOverview from './sections/AcademicOverview.jsx'
import Reports from './sections/Reports.jsx'
import Settings from './sections/Settings.jsx'

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'analytics', label: 'University Analytics', icon: 'chart' },
  { id: 'financial', label: 'Financial Overview', icon: 'finance' },
  { id: 'academic', label: 'Academic Overview', icon: 'school' },
  { id: 'reports', label: 'Reports', icon: 'reports' },
  { id: 'settings', label: 'Settings', icon: 'settings' }
]

export default function VcDashboard() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const store = useDataStore()
  const [activeId, setActiveId] = useState('dashboard')

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const totalRevenue = store.receipts.reduce((sum, r) => sum + r.amount, 0)
  const fullyRegistered = store.forms.filter((f) => STAGE_ORDER.every((k) => f.stages[k].status === 'Approved'))
  const registrationRate = store.forms.length
    ? Math.round((fullyRegistered.length / store.forms.length) * 100)
    : 0

  const sharedProps = {
    students: store.students,
    totalRevenue,
    registrationRate,
    fullyRegistered: fullyRegistered.length,
    totalForms: store.forms.length
  }

  const sections = {
    dashboard: <Overview {...sharedProps} />,
    analytics: <UniversityAnalytics />,
    financial: <FinancialOverview {...sharedProps} />,
    academic: <AcademicOverview {...sharedProps} />,
    reports: <Reports {...sharedProps} />,
    settings: <Settings />
  }

  return (
    <DashboardShell
      theme={THEME.vc}
      officeLabel="Vice Chancellor's Office"
      navItems={NAV_ITEMS}
      activeId={activeId}
      onSelect={setActiveId}
      onLogout={handleLogout}
      pageTitle="Vice Chancellor Dashboard"
      user={{ name: user?.name, idNumber: user?.idNumber }}
    >
      {sections[activeId]}
    </DashboardShell>
  )
}
