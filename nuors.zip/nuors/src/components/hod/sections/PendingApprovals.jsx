import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildQueueColumns } from './columns.jsx'

export default function PendingApprovals({ actionable, notYetReady, studentName, getStudent, decide, toggleHold }) {
  const columns = buildQueueColumns({ stage: 'hod', showActions: true, decide, toggleHold, studentName, getStudent })
  return (
    <Card title="Pending Approvals">
      <DataTable columns={columns} rows={actionable} />
      {notYetReady.length > 0 && (
        <p className="text-xs text-gray-400 mt-3">
          {notYetReady.length} more form(s) are waiting on Finance/Audit verification before they reach you.
        </p>
      )}
    </Card>
  )
}
