import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'

export default function RejectedRegistrations({ rejected, studentName }) {
  return (
    <Card title="Rejected Registrations">
      <DataTable
        columns={[
          { key: 'id', label: 'Student', render: (r) => studentName(r.studentId) },
          { key: 'reason', label: 'Reason', render: (r) => r.stages.hod.reason }
        ]}
        rows={rejected}
      />
    </Card>
  )
}
