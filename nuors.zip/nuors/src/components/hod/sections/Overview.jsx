import StatCard from '../../common/StatCard.jsx'
import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { MiniBarChart, MiniPieChart, PieLegend } from '../../common/Charts.jsx'
import { THEME } from '../../../theme.js'
import { buildQueueColumns } from './columns.jsx'

export default function Overview({ forms, actionable, approved, rejected, notYetReady, studentName, getStudent, decide, toggleHold }) {
  const columns = buildQueueColumns({ stage: 'hod', showActions: true, decide, toggleHold, studentName, getStudent })

  const barData = [
    { name: 'Pending', value: actionable.length + notYetReady.length },
    { name: 'Approved', value: approved.length },
    { name: 'Rejected', value: rejected.length }
  ]
  const pieData = [
    { name: 'Approved', value: approved.length },
    { name: 'Pending', value: actionable.length + notYetReady.length },
    { name: 'Rejected', value: rejected.length }
  ]

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Pending Approvals" value={actionable.length} icon="pending" color="#f59e0b" />
        <StatCard label="Approved Registrations" value={approved.length} icon="approved" color="#22c55e" />
        <StatCard label="Rejected Registrations" value={rejected.length} icon="rejected" color="#ef4444" />
        <StatCard label="Total Students" value={forms.length} icon="users" color={THEME.hod.accent} />
      </div>

      <Card title="Pending Approvals">
        <DataTable columns={columns} rows={actionable} emptyText="No registrations awaiting your approval right now." />
      </Card>

      <div className="grid md:grid-cols-2 gap-5">
        <Card title="Department Summary">
          <MiniBarChart data={barData} color={THEME.hod.accent} />
        </Card>
        <Card title="Approval Summary">
          <MiniPieChart data={pieData} />
          <PieLegend data={pieData} />
        </Card>
      </div>
    </div>
  )
}
