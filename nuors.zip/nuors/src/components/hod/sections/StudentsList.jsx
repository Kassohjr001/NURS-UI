import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'

export default function StudentsList({ students }) {
  return (
    <Card title="Students List">
      <DataTable
        columns={[
          { key: 'id', label: 'Student ID', render: (r) => r.id },
          { key: 'name', label: 'Name', render: (r) => r.name },
          { key: 'programme', label: 'Programme', render: (r) => r.programme },
          { key: 'year', label: 'Year', render: (r) => r.year }
        ]}
        rows={students}
      />
    </Card>
  )
}
