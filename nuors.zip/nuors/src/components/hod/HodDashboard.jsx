import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import DashboardShell from '../layout/DashboardShell.jsx'
import { useAuth } from '../../context/AuthContext.jsx'
import { useDataStore } from '../../context/DataStoreContext.jsx'
import { THEME } from '../../theme.js'

import Overview from './sections/Overview.jsx'
import PendingApprovals from './sections/PendingApprovals.jsx'
import ApprovedRegistrations from './sections/ApprovedRegistrations.jsx'
import RejectedRegistrations from './sections/RejectedRegistrations.jsx'
import StudentsList from './sections/StudentsList.jsx'
import Reports from './sections/Reports.jsx'

const STAGE = 'hod'
const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'pending', label: 'Pending Approvals', icon: 'pending' },
  { id: 'approved', label: 'Approved Registrations', icon: 'approved' },
  { id: 'rejected', label: 'Rejected Registrations', icon: 'rejected' },
  { id: 'students', label: 'Students List', icon: 'users' },
  { id: 'reports', label: 'Reports', icon: 'reports' }
]

export default function HodDashboard() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const store = useDataStore()
  const [activeId, setActiveId] = useState('dashboard')

  const forms = store.forms
  const actionable = forms.filter((f) => store.canSignStage(f, STAGE) && f.stages[STAGE].status === 'Pending')
  const approved = forms.filter((f) => f.stages[STAGE].status === 'Approved')
  const rejected = forms.filter((f) => f.stages[STAGE].status === 'Rejected')
  const notYetReady = forms.filter((f) => !store.canSignStage(f, STAGE) && f.stages[STAGE].status === 'Pending')

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const studentName = (id) => store.getStudent(id)?.name || id

  const decide = (form, decision) => {
    if (decision === 'Rejected') {
      const reason = window.prompt(`Reason for rejecting ${form.fsNo} (flags Audit for re-verification):`)
      if (!reason) return
      store.signStage(form.id, STAGE, 'Rejected', reason)
    } else {
      store.signStage(form.id, STAGE, 'Approved')
    }
  }

  const toggleHold = (form) => store.holdForm(form.id, !form.hold)

  const sharedProps = {
    forms, actionable, approved, rejected, notYetReady,
    studentName, getStudent: store.getStudent, decide, toggleHold,
    students: store.students
  }

  const sections = {
    dashboard: <Overview {...sharedProps} />,
    pending: <PendingApprovals {...sharedProps} />,
    approved: <ApprovedRegistrations {...sharedProps} />,
    rejected: <RejectedRegistrations {...sharedProps} />,
    students: <StudentsList {...sharedProps} />,
    reports: <Reports {...sharedProps} />
  }

  return (
    <DashboardShell
      theme={THEME.hod}
      officeLabel="Head of Department"
      navItems={NAV_ITEMS}
      activeId={activeId}
      onSelect={setActiveId}
      onLogout={handleLogout}
      pageTitle="HOD Dashboard"
      user={{ name: user?.name, idNumber: user?.idNumber }}
    >
      {sections[activeId]}
    </DashboardShell>
  )
}
