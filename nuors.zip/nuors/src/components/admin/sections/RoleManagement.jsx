import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'

export default function RoleManagement({ roleCounts }) {
  return (
    <Card title="Role Management">
      <DataTable
        columns={[{ key: 'name', label: 'Role' }, { key: 'value', label: 'Accounts' }]}
        rows={roleCounts}
      />
    </Card>
  )
}
