import { useState } from 'react'
import { UserPlus } from 'lucide-react'
import Card from '../../common/Card.jsx'
import Badge from '../../common/Badge.jsx'
import DataTable from '../../common/DataTable.jsx'
import { ROLES } from '../../../theme.js'
import { ROLE_LABELS } from './constants.js'

export default function UserManagement({ accounts, createAccount, toggleAccountStatus }) {
  const [newName, setNewName] = useState('')
  const [newId, setNewId] = useState('')
  const [newRole, setNewRole] = useState('student')
  const [created, setCreated] = useState(false)

  const handleCreateAccount = (e) => {
    e.preventDefault()
    if (!newName || !newId) return
    createAccount({ name: newName, idNumber: newId, role: newRole })
    setNewName(''); setNewId('')
    setCreated(true)
    setTimeout(() => setCreated(false), 3000)
  }

  const accountColumns = [
    { key: 'id', label: 'Account ID' },
    { key: 'name', label: 'Name' },
    { key: 'idNumber', label: 'Login ID' },
    { key: 'role', label: 'Role', render: (r) => <span className="capitalize">{ROLE_LABELS[r.role] || r.role}</span> },
    { key: 'status', label: 'Status', render: (r) => <Badge status={r.status === 'Active' ? 'Approved' : 'Rejected'}>{r.status}</Badge> },
    {
      key: 'action',
      label: 'Action',
      render: (r) => (
        <button
          onClick={() => toggleAccountStatus(r.id)}
          className="text-xs font-semibold text-gray-600 bg-gray-100 px-2.5 py-1 rounded-md"
        >
          {r.status === 'Active' ? 'Suspend' : 'Activate'}
        </button>
      )
    }
  ]

  return (
    <div className="space-y-5">
      <Card title="Create New Account">
        <p className="text-xs text-gray-500 mb-4">
          Only the System Admin can create accounts. Every student and staff member — Audit, Finance, Exams,
          HOD, Dean, Registrar, Vice Chancellor — signs in through the same login page once their account exists
          here.
        </p>
        <form onSubmit={handleCreateAccount} className="grid sm:grid-cols-4 gap-3 items-end">
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Full name"
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm"
          />
          <input
            value={newId}
            onChange={(e) => setNewId(e.target.value)}
            placeholder="Login ID (e.g. STAFF-HOD-02)"
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm"
          />
          <select
            value={newRole}
            onChange={(e) => setNewRole(e.target.value)}
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm capitalize"
          >
            {Object.values(ROLES).map((r) => (
              <option key={r} value={r}>{ROLE_LABELS[r]}</option>
            ))}
          </select>
          <button type="submit" className="flex items-center justify-center gap-2 bg-sky-600 text-white text-sm font-semibold rounded-lg py-2.5">
            <UserPlus size={15} /> Create Account
          </button>
        </form>
        {created && (
          <p className="text-xs text-green-600 mt-3">
            Account created — share the temporary password <span className="font-mono font-semibold">Welcome123</span> with
            them. They'll be required to set their own on first sign-in.
          </p>
        )}
      </Card>

      <Card title="All Accounts">
        <DataTable columns={accountColumns} rows={accounts} />
      </Card>
    </div>
  )
}
