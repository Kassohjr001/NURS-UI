import Card from '../../common/Card.jsx'

export default function Settings({ resetDemoData }) {
  return (
    <Card title="Settings">
      <button
        onClick={resetDemoData}
        className="text-sm font-semibold text-red-600 bg-red-50 px-4 py-2.5 rounded-lg"
      >
        Reset Demo Data
      </button>
      <p className="text-xs text-gray-400 mt-2">Restores every dashboard to its original seeded state.</p>
    </Card>
  )
}
