import Card from '../../common/Card.jsx'
import { ROLE_LABELS } from './constants.js'

export default function SystemLogs({ accounts }) {
  return (
    <Card title="System Logs">
      <ul className="space-y-2 text-sm text-gray-600">
        {accounts.map((a) => (
          <li key={a.id}>Account {a.idNumber} ({ROLE_LABELS[a.role]}) — {a.status}</li>
        ))}
      </ul>
    </Card>
  )
}
