import Card from '../../common/Card.jsx'
import Badge from '../../common/Badge.jsx'
import DataTable from '../../common/DataTable.jsx'
import { DEPARTMENTS } from '../../../data/mockData.js'

export default function Departments() {
  return (
    <Card title="Faculties & Departments">
      <DataTable
        columns={[
          { key: 'name', label: 'Department' },
          { key: 'students', label: 'Students' },
          { key: 'resultsPublished', label: 'Results Published', render: (r) => <Badge status={r.resultsPublished ? 'Approved' : 'Pending'}>{r.resultsPublished ? 'Yes' : 'No'}</Badge> }
        ]}
        rows={DEPARTMENTS}
      />
    </Card>
  )
}
