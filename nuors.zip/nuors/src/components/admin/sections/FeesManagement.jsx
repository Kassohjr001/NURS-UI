import Card from '../../common/Card.jsx'

export default function FeesManagement() {
  return (
    <Card title="Fees Management">
      <ul className="space-y-2 text-sm text-gray-600">
        <li>First-year students: 100% of fees required before registration proceeds.</li>
        <li>Continuing students: two installments — 60% to start, 40% before final clearance.</li>
      </ul>
    </Card>
  )
}
