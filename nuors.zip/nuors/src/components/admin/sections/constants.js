export const ROLE_LABELS = {
  student: 'Student',
  audit: 'Audit',
  finance: 'Finance',
  exams: 'Exams Office',
  hod: 'HOD',
  dean: 'Dean',
  registrar: 'Department Registrar',
  admin: 'System Admin',
  vc: 'Vice Chancellor'
}
