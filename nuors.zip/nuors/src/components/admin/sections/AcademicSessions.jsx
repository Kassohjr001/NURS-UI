import Card from '../../common/Card.jsx'
import { SEMESTER } from '../../../data/mockData.js'

export default function AcademicSessions() {
  return (
    <Card title="Academic Sessions">
      <p className="text-sm text-gray-600">Current active session: <span className="font-semibold">{SEMESTER}</span></p>
      <p className="text-xs text-gray-400 mt-2">
        Session switching, archiving past semesters, and locking registration windows would be managed here.
      </p>
    </Card>
  )
}
