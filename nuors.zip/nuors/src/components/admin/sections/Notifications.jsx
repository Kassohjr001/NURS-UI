import { useState } from 'react'
import { Megaphone } from 'lucide-react'
import Card from '../../common/Card.jsx'

export default function Notifications({ notifications, sendNotification }) {
  const [noticeText, setNoticeText] = useState('')
  const [noticeSent, setNoticeSent] = useState(false)

  const handleSendNotice = (e) => {
    e.preventDefault()
    if (!noticeText) return
    sendNotification(noticeText, 'all')
    setNoticeText('')
    setNoticeSent(true)
    setTimeout(() => setNoticeSent(false), 3000)
  }

  return (
    <div className="space-y-5">
      <Card title="Broadcast Notification">
        <form onSubmit={handleSendNotice} className="flex gap-3">
          <input
            value={noticeText}
            onChange={(e) => setNoticeText(e.target.value)}
            placeholder="e.g. Second semester registration closes on July 1st"
            className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm"
          />
          <button type="submit" className="flex items-center gap-2 bg-sky-600 text-white text-sm font-semibold rounded-lg px-4 py-2.5">
            <Megaphone size={15} /> Send to All Students
          </button>
        </form>
        {noticeSent && <p className="text-xs text-green-600 mt-3">Sent — it now appears on every student's Notifications tab.</p>}
      </Card>
      <Card title="Sent Notifications">
        <ul className="space-y-2 text-sm text-gray-600">
          {notifications.map((n) => (
            <li key={n.id}>{n.message} <span className="text-xs text-gray-400">— {n.date}</span></li>
          ))}
        </ul>
      </Card>
    </div>
  )
}
