import Card from '../../common/Card.jsx'

export default function Reports({ accounts, activeUsers, staffAccounts, students }) {
  return (
    <Card title="Reports">
      <p className="text-sm text-gray-500">
        Total Accounts: {accounts.length} · Active: {activeUsers} · Staff: {staffAccounts} · Students: {students.length}
      </p>
    </Card>
  )
}
