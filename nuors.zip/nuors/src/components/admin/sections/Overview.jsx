import StatCard from '../../common/StatCard.jsx'
import Card from '../../common/Card.jsx'
import { MiniLineChart, MiniPieChart, PieLegend } from '../../common/Charts.jsx'
import { DEPARTMENTS } from '../../../data/mockData.js'
import { THEME } from '../../../theme.js'
import { ROLE_LABELS } from './constants.js'

export default function Overview({ accounts, students, roleCounts, activeUsers, staffAccounts }) {
  const usageTrend = [
    { name: 'Mon', value: 320 }, { name: 'Tue', value: 410 }, { name: 'Wed', value: 380 },
    { name: 'Thu', value: 460 }, { name: 'Fri', value: 500 }, { name: 'Sat', value: 280 }
  ]

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Students" value={students.length} icon="users" color={THEME.admin.accent} />
        <StatCard label="Active Users" value={activeUsers} icon="approved" color="#22c55e" />
        <StatCard label="Staff Accounts" value={staffAccounts} icon="admin" color="#a855f7" />
        <StatCard label="Departments" value={DEPARTMENTS.length} icon="department" color="#f59e0b" />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <Card title="System Overview (logins this week)">
          <MiniLineChart data={usageTrend} color={THEME.admin.accent} />
        </Card>
        <Card title="User Roles">
          <MiniPieChart data={roleCounts} />
          <PieLegend data={roleCounts} />
        </Card>
      </div>

      <Card title="Recent System Logs">
        <ul className="space-y-2 text-sm text-gray-600">
          {accounts.slice(0, 5).map((a) => (
            <li key={a.id}>Account {a.id} ({ROLE_LABELS[a.role]}) — {a.status}</li>
          ))}
        </ul>
      </Card>
    </div>
  )
}
