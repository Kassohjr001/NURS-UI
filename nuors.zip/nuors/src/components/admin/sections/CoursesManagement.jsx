import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { COURSES } from '../../../data/mockData.js'

export default function CoursesManagement() {
  return (
    <Card title="Courses Management">
      <DataTable columns={[{ key: 'code', label: 'Code' }, { key: 'title', label: 'Title' }, { key: 'credits', label: 'Credits' }]} rows={COURSES} />
    </Card>
  )
}
