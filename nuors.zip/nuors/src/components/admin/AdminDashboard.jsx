import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import DashboardShell from '../layout/DashboardShell.jsx'
import { useAuth } from '../../context/AuthContext.jsx'
import { useDataStore } from '../../context/DataStoreContext.jsx'
import { THEME, ROLES } from '../../theme.js'
import { ROLE_LABELS } from './sections/constants.js'

import Overview from './sections/Overview.jsx'
import UserManagement from './sections/UserManagement.jsx'
import RoleManagement from './sections/RoleManagement.jsx'
import AcademicSessions from './sections/AcademicSessions.jsx'
import Departments from './sections/Departments.jsx'
import CoursesManagement from './sections/CoursesManagement.jsx'
import FeesManagement from './sections/FeesManagement.jsx'
import Notifications from './sections/Notifications.jsx'
import SystemLogs from './sections/SystemLogs.jsx'
import Reports from './sections/Reports.jsx'
import Settings from './sections/Settings.jsx'

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'users', label: 'User Management', icon: 'users' },
  { id: 'roles', label: 'Role Management', icon: 'roles' },
  { id: 'sessions', label: 'Academic Sessions', icon: 'calendar' },
  { id: 'departments', label: 'Faculties & Departments', icon: 'department' },
  { id: 'courses', label: 'Courses Management', icon: 'courses' },
  { id: 'fees', label: 'Fees Management', icon: 'finance' },
  { id: 'notifications', label: 'Notifications', icon: 'notifications' },
  { id: 'logs', label: 'System Logs', icon: 'logs' },
  { id: 'reports', label: 'Reports', icon: 'reports' },
  { id: 'settings', label: 'Settings', icon: 'settings' }
]

export default function AdminDashboard() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const store = useDataStore()
  const [activeId, setActiveId] = useState('dashboard')

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const roleCounts = Object.values(ROLES).map((role) => ({
    name: ROLE_LABELS[role],
    value: store.accounts.filter((a) => a.role === role).length
  }))
  const activeUsers = store.accounts.filter((a) => a.status === 'Active').length
  const staffAccounts = store.accounts.filter((a) => a.role !== 'student').length

  const sharedProps = {
    accounts: store.accounts,
    students: store.students,
    notifications: store.notifications,
    roleCounts, activeUsers, staffAccounts,
    createAccount: store.createAccount,
    toggleAccountStatus: store.toggleAccountStatus,
    sendNotification: store.sendNotification,
    resetDemoData: store.resetDemoData
  }

  const sections = {
    dashboard: <Overview {...sharedProps} />,
    users: <UserManagement {...sharedProps} />,
    roles: <RoleManagement {...sharedProps} />,
    sessions: <AcademicSessions />,
    departments: <Departments />,
    courses: <CoursesManagement />,
    fees: <FeesManagement />,
    notifications: <Notifications {...sharedProps} />,
    logs: <SystemLogs {...sharedProps} />,
    reports: <Reports {...sharedProps} />,
    settings: <Settings {...sharedProps} />
  }

  return (
    <DashboardShell
      theme={THEME.admin}
      officeLabel="System Administration"
      navItems={NAV_ITEMS}
      activeId={activeId}
      onSelect={setActiveId}
      onLogout={handleLogout}
      pageTitle="System Admin Dashboard"
      user={{ name: user?.name, idNumber: user?.idNumber }}
    >
      {sections[activeId]}
    </DashboardShell>
  )
}
