import { useState } from 'react'
import { Upload } from 'lucide-react'
import Card from '../../common/Card.jsx'
import Badge from '../../common/Badge.jsx'
import DataTable from '../../common/DataTable.jsx'
import { useDataStore } from '../../../context/DataStoreContext.jsx'

export default function Payments({ studentId, slips }) {
  const store = useDataStore()
  const student = store.getStudent(studentId)
  const isFirstYear = student?.year === 1
  const [type, setType] = useState(isFirstYear ? 'Full Payment' : 'Installment 1 (60%)')
  const [amount, setAmount] = useState('')
  const [fileName, setFileName] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!amount) return
    store.submitSlip(studentId, { type, amount, fileName: fileName || 'payment_slip.pdf' })
    setAmount('')
    setFileName('')
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
  }

  const columns = [
    { key: 'id', label: 'Slip ID' },
    { key: 'type', label: 'Type' },
    { key: 'amount', label: 'Amount', render: (r) => `Le ${r.amount.toLocaleString()}` },
    { key: 'dateSubmitted', label: 'Date' },
    { key: 'status', label: 'Status', render: (r) => <Badge status={r.hold ? 'Hold' : r.status} /> },
    { key: 'reason', label: 'Note', render: (r) => r.reason || (r.receiptGenerated ? 'Receipt issued' : '—') }
  ]

  return (
    <div className="space-y-5">
      <Card title="Upload Payment Slip">
        <p className="text-xs text-gray-500 mb-4">
          {isFirstYear
            ? 'As a first-year student, you must pay 100% of your fees before you can register.'
            : 'As a continuing student, you may pay in two installments: 60% to start registration, then the remaining 40% before final clearance.'}
        </p>
        <form onSubmit={handleSubmit} className="grid sm:grid-cols-4 gap-3 items-end">
          <div className="sm:col-span-1">
            <label className="block text-xs font-semibold text-gray-500 mb-1.5">Payment Type</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm"
            >
              {isFirstYear ? (
                <option>Full Payment</option>
              ) : (
                <>
                  <option>Installment 1 (60%)</option>
                  <option>Installment 2 (40%)</option>
                </>
              )}
            </select>
          </div>
          <div className="sm:col-span-1">
            <label className="block text-xs font-semibold text-gray-500 mb-1.5">Amount Paid (Le)</label>
            <input
              required
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g. 6000000"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm"
            />
          </div>
          <div className="sm:col-span-1">
            <label className="block text-xs font-semibold text-gray-500 mb-1.5">Bank Slip File</label>
            <input
              type="text"
              value={fileName}
              onChange={(e) => setFileName(e.target.value)}
              placeholder="slip_scan.pdf"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm"
            />
          </div>
          <button
            type="submit"
            className="flex items-center justify-center gap-2 bg-teal-700 text-white text-sm font-semibold rounded-lg py-2.5 sm:col-span-1"
          >
            <Upload size={15} />
            Submit Slip
          </button>
        </form>
        {submitted && (
          <p className="text-xs text-green-600 mt-3">
            Slip submitted. It now appears in the Audit Office's pending review queue.
          </p>
        )}
      </Card>

      <Card title="My Payment Slips">
        <DataTable columns={columns} rows={slips} emptyText="You haven't submitted any payment slips yet." />
      </Card>
    </div>
  )
}
