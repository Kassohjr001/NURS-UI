import { Lock, Clock } from 'lucide-react'
import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { RESULTS } from '../../../data/mockData.js'
import { useDataStore } from '../../../context/DataStoreContext.jsx'

export default function Results({ studentId, forms }) {
  const store = useDataStore()
  const latestForm = forms[0]
  const fullyCleared = latestForm && latestForm.stages.registrar.status === 'Approved'
  const grades = RESULTS[studentId] || []

  const columns = [
    { key: 'course', label: 'Course' },
    { key: 'grade', label: 'Grade' },
    { key: 'credits', label: 'Credits' }
  ]

  if (!fullyCleared) {
    return (
      <Card title="Results">
        <div className="flex items-center gap-3 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-4 py-3">
          <Lock size={18} />
          <p className="text-sm">
            Results unlock once your fees are fully paid and your registration form is fully signed off by all
            offices.
          </p>
        </div>
      </Card>
    )
  }

  if (!store.resultsPublished) {
    return (
      <Card title="Results">
        <div className="flex items-center gap-3 text-blue-700 bg-blue-50 border border-blue-200 rounded-lg px-4 py-3">
          <Clock size={18} />
          <p className="text-sm">
            Your registration is fully cleared — you're all set. The Exams Office hasn't published results for this
            semester yet; you'll get a notification the moment they do.
          </p>
        </div>
      </Card>
    )
  }

  return (
    <Card title="My Results">
      <DataTable columns={columns} rows={grades} emptyText="No results recorded for you yet, even though results are published." />
    </Card>
  )
}
