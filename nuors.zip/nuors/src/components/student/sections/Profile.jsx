import Card from '../../common/Card.jsx'

function Field({ label, value }) {
  return (
    <div>
      <p className="text-xs text-gray-400">{label}</p>
      <p className="text-sm font-medium text-gray-800 mt-0.5">{value || '—'}</p>
    </div>
  )
}

export default function Profile({ student }) {
  if (!student) return null
  return (
    <Card title="My Profile" className="max-w-3xl">
      <p className="text-xs text-gray-400 mb-4">
        These fields mirror Section A of the official semester registration form.
      </p>
      <div className="grid sm:grid-cols-2 gap-5">
        <Field label="Surname" value={student.surname || student.name?.split(' ').slice(-1)[0]} />
        <Field label="First Name" value={student.firstName || student.name?.split(' ')[0]} />
        <Field label="Matriculation Number" value={student.matNo} />
        <Field label="Date of Birth" value={student.dob} />
        <Field label="Phone Number" value={student.phone} />
        <Field label="Sex" value={student.sex} />
        <Field label="Nationality" value={student.nationality} />
        <Field label="Contact Address" value={student.address} />
        <Field label="Parent / Guardian" value={student.parentGuardian} />
        <Field label="School" value={student.school} />
        <Field label="Programme" value={student.programme} />
        <Field label="Major" value={student.major} />
        <Field label="Minor" value={student.minor} />
        <Field label="Year of Programme" value={student.year} />
        <Field label="Sponsor" value={student.sponsor} />
      </div>
      <p className="text-xs text-gray-400 mt-5">
        To correct any of these details, contact the Department Registrar — student profile fields are set at account
        creation by the System Admin.
      </p>
    </Card>
  )
}
