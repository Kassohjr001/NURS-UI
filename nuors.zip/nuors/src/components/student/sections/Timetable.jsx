import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { useDataStore } from '../../../context/DataStoreContext.jsx'

export default function Timetable() {
  const store = useDataStore()
  const columns = [
    { key: 'course', label: 'Course' },
    { key: 'date', label: 'Date' },
    { key: 'time', label: 'Time' },
    { key: 'venue', label: 'Venue' }
  ]
  return (
    <Card title="Examination Timetable">
      <DataTable columns={columns} rows={store.timetable} />
    </Card>
  )
}
