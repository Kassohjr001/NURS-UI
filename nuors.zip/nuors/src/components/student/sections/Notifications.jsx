import { Bell } from 'lucide-react'
import Card from '../../common/Card.jsx'
import { NOTIFICATIONS } from '../../../data/mockData.js'
import { useDataStore } from '../../../context/DataStoreContext.jsx'

export default function Notifications({ studentId }) {
  const store = useDataStore()
  const live = store.notifications.filter((n) => n.audience === 'all' || n.audience === studentId)
  const seeded = NOTIFICATIONS.filter((n) => n.audience === 'all' || n.audience === studentId)
  const items = [...live, ...seeded]

  return (
    <Card title="Notifications">
      <ul className="space-y-3">
        {items.map((n) => (
          <li key={n.id} className="flex items-start gap-3 text-sm">
            <Bell size={16} className="text-teal-600 mt-0.5 shrink-0" />
            <div>
              <p className="text-gray-700">{n.message}</p>
              <p className="text-xs text-gray-400 mt-0.5">{n.date}</p>
            </div>
          </li>
        ))}
      </ul>
    </Card>
  )
}
