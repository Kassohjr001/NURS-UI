import { Upload, Download, BookOpen, FileText, GraduationCap, CalendarClock } from 'lucide-react'
import ProgressStepper from '../../common/ProgressStepper.jsx'
import WorkflowTracker from '../../common/WorkflowTracker.jsx'
import Card from '../../common/Card.jsx'
import { NOTIFICATIONS } from '../../../data/mockData.js'
import { useDataStore, STAGE_ORDER, STAGE_LABEL } from '../../../context/DataStoreContext.jsx'

export default function Overview({ student, forms, slips, onNavigate }) {
  const store = useDataStore()
  const latestForm = forms[0]
  const anySlipApproved = slips.some((s) => s.status === 'Approved')
  const anyReceipt = slips.some((s) => s.receiptGenerated)
  const courseRegistered = Boolean(latestForm)
  const deptApproved = latestForm && latestForm.stages.finance.status === 'Approved' && latestForm.stages.audit.status === 'Approved'
  const hodApproved = latestForm && latestForm.stages.hod.status === 'Approved'
  const deanApproved = latestForm && latestForm.stages.dean.status === 'Approved'
  const completed = latestForm && latestForm.stages.registrar.status === 'Approved'

  const steps = [
    { label: 'Payment Submitted', done: slips.length > 0 },
    { label: 'Audit Approved', done: anySlipApproved },
    { label: 'Finance Approved', done: anyReceipt },
    { label: 'Course Registration', done: courseRegistered },
    { label: 'Dept. Approved', done: Boolean(deptApproved) },
    { label: 'HOD Approved', done: Boolean(hodApproved) },
    { label: 'Dean Approved', done: Boolean(deanApproved) },
    { label: 'Registration Completed', done: Boolean(completed) }
  ]

  const quickLinks = [
    { id: 'payments', label: 'Upload Slip', icon: Upload },
    { id: 'receipts', label: 'Download Receipt', icon: Download },
    { id: 'courses', label: 'Register Courses', icon: BookOpen },
    { id: 'forms', label: 'Registration Form', icon: FileText },
    { id: 'results', label: 'Check Results', icon: GraduationCap },
    { id: 'timetable', label: 'Exam Timetable', icon: CalendarClock }
  ]

  const announcements = NOTIFICATIONS.filter((n) => n.audience === 'all' || n.audience === student?.id)

  return (
    <div className="space-y-5">
      <Card>
        <h2 className="font-display font-bold text-xl text-gray-800">Welcome back, {student?.name}</h2>
        <p className="text-sm text-gray-500 mt-1">
          Student ID: {student?.id} &nbsp;·&nbsp; Department: {student?.major}
        </p>
      </Card>

      <Card title="Registration Progress">
        <ProgressStepper steps={steps} accentColor="#0f5e59" />
      </Card>

      <Card title="Registration Workflow Status">
        {latestForm ? (
          <WorkflowTracker stageOrder={STAGE_ORDER} stages={latestForm.stages} stageLabel={STAGE_LABEL} hold={latestForm.hold} />
        ) : (
          <p className="text-sm text-gray-500">
            You haven't submitted a registration form for this semester yet. Once you do, you'll see exactly which
            office it's sitting with — Finance, Audit, HOD, Dean, or the Registrar — right here.
          </p>
        )}
      </Card>

      <Card title="Quick Links">
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
          {quickLinks.map((q) => (
            <button
              key={q.id}
              onClick={() => onNavigate(q.id)}
              className="flex flex-col items-center gap-2 py-4 rounded-xl border border-gray-100 hover:border-teal-200 hover:bg-teal-50 transition-colors"
            >
              <q.icon size={20} className="text-teal-700" />
              <span className="text-xs text-gray-600 text-center leading-tight">{q.label}</span>
            </button>
          ))}
        </div>
      </Card>

      <div className="grid md:grid-cols-2 gap-5">
        <Card title="Announcements">
          <ul className="space-y-3">
            {announcements.map((a) => (
              <li key={a.id} className="text-sm">
                <p className="text-gray-700">{a.message}</p>
                <p className="text-xs text-gray-400 mt-0.5">{a.date}</p>
              </li>
            ))}
          </ul>
        </Card>
        <Card title="Upcoming Calendar">
          <ul className="space-y-3">
            {store.calendarEvents.map((e) => (
              <li key={e.title} className="flex items-center justify-between text-sm">
                <span className="text-gray-700">{e.title}</span>
                <span className="text-xs text-gray-400">{e.date}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  )
}
