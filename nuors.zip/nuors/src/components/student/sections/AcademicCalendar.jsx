import Card from '../../common/Card.jsx'
import { useDataStore } from '../../../context/DataStoreContext.jsx'

export default function AcademicCalendar() {
  const store = useDataStore()
  return (
    <Card title="Academic Calendar — 2025/2026">
      <ul className="divide-y divide-gray-100">
        {store.calendarEvents.map((e) => (
          <li key={e.title} className="flex items-center justify-between py-3 text-sm">
            <span className="text-gray-700">{e.title}</span>
            <span className="text-xs font-semibold text-gray-400">{e.date}</span>
          </li>
        ))}
      </ul>
    </Card>
  )
}
