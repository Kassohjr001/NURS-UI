import { useState } from 'react'
import { BookOpen, Lock } from 'lucide-react'
import Card from '../../common/Card.jsx'
import { useDataStore } from '../../../context/DataStoreContext.jsx'
import { COURSES as AVAILABLE_COURSES } from '../../../data/mockData.js'

export default function CourseRegistration({ studentId, receipts, forms }) {
  const store = useDataStore()
  const [selected, setSelected] = useState([])
  const [submitted, setSubmitted] = useState(false)

  const hasReceipt = receipts.length > 0
  const alreadySubmitted = forms.length > 0

  const toggle = (code) => {
    setSelected((s) => (s.includes(code) ? s.filter((c) => c !== code) : [...s, code]))
  }

  const credits = selected.reduce((sum, code) => sum + (AVAILABLE_COURSES.find((c) => c.code === code)?.credits || 0), 0)

  const handleSubmit = () => {
    if (selected.length === 0) return
    store.submitRegistrationForm(studentId, selected)
    setSubmitted(true)
  }

  if (!hasReceipt) {
    return (
      <Card title="Course Registration">
        <div className="flex items-center gap-3 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-4 py-3">
          <Lock size={18} />
          <p className="text-sm">
            Course registration unlocks once Finance has issued your University Receipt. Submit a payment slip under
            the Payments tab to get started.
          </p>
        </div>
      </Card>
    )
  }

  if (alreadySubmitted || submitted) {
    return (
      <Card title="Course Registration">
        <p className="text-sm text-gray-600">
          You've already submitted your registration form for this semester. Track its signature progress under the
          <span className="font-semibold"> Registration Forms</span> tab.
        </p>
      </Card>
    )
  }

  return (
    <Card title="Select Your Courses">
      <p className="text-xs text-gray-500 mb-4">
        Choose your courses for this semester. These course codes will appear on your registration form for HOD and
        Dean approval.
      </p>
      <div className="grid sm:grid-cols-2 gap-3">
        {AVAILABLE_COURSES.map((c) => (
          <label
            key={c.code}
            className={`flex items-center gap-3 border rounded-lg px-3 py-2.5 cursor-pointer ${
              selected.includes(c.code) ? 'border-teal-400 bg-teal-50' : 'border-gray-200'
            }`}
          >
            <input type="checkbox" checked={selected.includes(c.code)} onChange={() => toggle(c.code)} />
            <div>
              <p className="text-sm font-semibold text-gray-800">{c.code}</p>
              <p className="text-xs text-gray-500">{c.title} · {c.credits} credits</p>
            </div>
          </label>
        ))}
      </div>

      <div className="flex items-center justify-between mt-5 pt-4 border-t border-gray-100">
        <p className="text-sm text-gray-600">
          Selected: <span className="font-semibold">{selected.length}</span> courses · {credits} credits
        </p>
        <button
          onClick={handleSubmit}
          disabled={selected.length === 0}
          className="flex items-center gap-2 bg-teal-700 disabled:bg-gray-300 text-white text-sm font-semibold rounded-lg px-5 py-2.5"
        >
          <BookOpen size={15} />
          Submit Registration Form
        </button>
      </div>
    </Card>
  )
}
