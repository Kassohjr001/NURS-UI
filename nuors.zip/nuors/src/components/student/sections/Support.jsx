import Card from '../../common/Card.jsx'

const FAQ = [
  { q: 'How do I pay my fees?', a: 'Go to Payments, upload your bank slip with the amount and type, then submit. Audit verifies it against the bank statement before Finance issues your receipt.' },
  { q: 'How do I register my courses?', a: 'Once Finance issues your receipt, go to Course Registration, select your courses, and submit. Your form then syncs to Finance, Audit, HOD, Dean, and the Registrar for signing.' },
  { q: 'How do I know where my registration is stuck?', a: 'Open Registration Forms — each office shows Pending, Approved, or Rejected with a reason if rejected.' },
  { q: 'When can I see my results?', a: 'Once your registration is fully signed and your fees fully paid, results appear under the Results tab and you will get a notification.' }
]

export default function Support() {
  return (
    <Card title="Support & FAQ">
      <p className="text-sm text-gray-500 mb-4">
        Use the chat assistant in the bottom-right corner for quick answers, or browse common questions below.
      </p>
      <div className="space-y-4">
        {FAQ.map((item) => (
          <div key={item.q} className="border border-gray-100 rounded-lg p-3">
            <p className="text-sm font-semibold text-gray-800">{item.q}</p>
            <p className="text-sm text-gray-500 mt-1">{item.a}</p>
          </div>
        ))}
      </div>
    </Card>
  )
}
