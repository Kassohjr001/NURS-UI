import { Download } from 'lucide-react'
import Card from '../../common/Card.jsx'
import WorkflowTracker from '../../common/WorkflowTracker.jsx'
import { STAGE_ORDER, STAGE_LABEL } from '../../../context/DataStoreContext.jsx'
import { generateFormPdf } from '../../../utils/generateFormPdf.js'
import { useDataStore } from '../../../context/DataStoreContext.jsx'

export default function RegistrationForms({ forms }) {
  const store = useDataStore()

  if (forms.length === 0) {
    return (
      <Card title="Registration Forms">
        <p className="text-sm text-gray-500">
          You haven't submitted a registration form yet. Go to Course Registration to select your courses and submit.
        </p>
      </Card>
    )
  }

  return (
    <div className="space-y-5">
      {forms.map((form) => {
        const student = store.getStudent(form.studentId)
        return (
          <Card key={form.id} title={`Form ${form.fsNo} — ${form.semester}`}>
            <p className="text-xs text-gray-500 mb-4">Courses: {form.courseCodes.join(', ')}</p>

            <WorkflowTracker stageOrder={STAGE_ORDER} stages={form.stages} stageLabel={STAGE_LABEL} hold={form.hold} />

            <div className="flex items-center justify-end mt-4 pt-3 border-t border-gray-100">
              <button
                onClick={() => generateFormPdf(student, form)}
                className="flex items-center gap-2 text-sm font-semibold text-teal-700 hover:underline"
              >
                <Download size={15} /> Download PDF
              </button>
            </div>
          </Card>
        )
      })}
    </div>
  )
}
