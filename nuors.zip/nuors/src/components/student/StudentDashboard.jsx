import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import DashboardShell from '../layout/DashboardShell.jsx'
import ChatbotWidget from '../common/ChatbotWidget.jsx'
import { useAuth } from '../../context/AuthContext.jsx'
import { useDataStore, STAGE_ORDER } from '../../context/DataStoreContext.jsx'
import { THEME } from '../../theme.js'

import Overview from './sections/Overview.jsx'
import Profile from './sections/Profile.jsx'
import Payments from './sections/Payments.jsx'
import Receipts from './sections/Receipts.jsx'
import CourseRegistration from './sections/CourseRegistration.jsx'
import RegistrationForms from './sections/RegistrationForms.jsx'
import Results from './sections/Results.jsx'
import Timetable from './sections/Timetable.jsx'
import AcademicCalendar from './sections/AcademicCalendar.jsx'
import Notifications from './sections/Notifications.jsx'
import Support from './sections/Support.jsx'

const FULL_NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'profile', label: 'Profile', icon: 'profile' },
  { id: 'payments', label: 'Payments', icon: 'payments' },
  { id: 'receipts', label: 'Receipts', icon: 'receipts' },
  { id: 'courses', label: 'Course Registration', icon: 'courses' },
  { id: 'forms', label: 'Registration Forms', icon: 'forms' },
  { id: 'results', label: 'Results', icon: 'results' },
  { id: 'timetable', label: 'Timetable', icon: 'calendar' },
  { id: 'calendar', label: 'Academic Calendar', icon: 'calendar' },
  { id: 'notifications', label: 'Notifications', icon: 'notifications' },
  { id: 'support', label: 'Support', icon: 'support' }
]

// "Exceptional" accounts: registered but not actively going through this
// semester's pipeline. They only get reference info — grades, timetable,
// and the academic calendar — nothing involving payments or registration.
const VIEW_ONLY_NAV_ITEMS = [
  { id: 'results', label: 'Results', icon: 'results' },
  { id: 'timetable', label: 'Timetable', icon: 'calendar' },
  { id: 'calendar', label: 'Academic Calendar', icon: 'calendar' },
  { id: 'support', label: 'Support', icon: 'support' }
]

export default function StudentDashboard() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const store = useDataStore()

  const studentId = useMemo(() => {
    const match = store.students.find((s) => s.id === user?.idNumber)
    return match ? match.id : 'NU/CSC/2020/001'
  }, [user, store.students])

  const student = store.getStudent(studentId)
  const isViewOnly = student?.accountMode === 'view_only'

  const [activeId, setActiveId] = useState(isViewOnly ? 'results' : 'dashboard')

  const slips = store.slips.filter((s) => s.studentId === studentId)
  const receipts = store.receipts.filter((r) => r.studentId === studentId)
  const forms = store.forms.filter((f) => f.studentId === studentId)
  const latestForm = forms[0]

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const respond = (text) => {
    const q = text.toLowerCase()
    if (isViewOnly) {
      return 'This is a reference-only account — it can view results, timetable, and the academic calendar. For payments or registration, contact the Department Registrar to discuss upgrading your account.'
    }
    if (q.includes('registration') || q.includes('status') || q.includes('where')) {
      if (!latestForm) return "You haven't submitted a registration form for this semester yet. Head to Course Registration to get started."
      const stages = STAGE_ORDER.map((k) => `${k}: ${latestForm.stages[k].status}`).join(', ')
      return `Your latest registration form (${latestForm.fsNo}) status — ${stages}.`
    }
    if (q.includes('slip') || q.includes('payment') || q.includes('pay')) {
      return 'Go to the Payments tab, click "Upload Payment Slip", attach your bank slip, and submit. Audit will verify it against the bank statement before Finance issues your receipt.'
    }
    if (q.includes('result')) {
      return 'Results are released once your fees are fully paid and your registration is fully signed off. Check the Results tab — you will also get a notification the day results are published.'
    }
    if (q.includes('timetable')) {
      return 'Your exam timetable is under the Timetable tab. You will be notified automatically whenever the Exams Office uploads a new one.'
    }
    if (q.includes('receipt')) {
      return 'Once Finance approves your slip, your official University Receipt appears under the Receipts tab and can be downloaded any time.'
    }
    return "I can help with payments, registration status, timetable, and results. Try asking something like 'where is my registration?'"
  }

  const sections = isViewOnly
    ? {
        results: <Results studentId={studentId} forms={forms} />,
        timetable: <Timetable />,
        calendar: <AcademicCalendar />,
        support: <Support />
      }
    : {
        dashboard: <Overview student={student} forms={forms} slips={slips} onNavigate={setActiveId} />,
        profile: <Profile student={student} />,
        payments: <Payments studentId={studentId} slips={slips} />,
        receipts: <Receipts receipts={receipts} slips={slips} />,
        courses: <CourseRegistration studentId={studentId} receipts={receipts} forms={forms} />,
        forms: <RegistrationForms forms={forms} />,
        results: <Results studentId={studentId} forms={forms} />,
        timetable: <Timetable />,
        calendar: <AcademicCalendar />,
        notifications: <Notifications studentId={studentId} />,
        support: <Support />
      }

  return (
    <>
      <DashboardShell
        theme={THEME.student}
        officeLabel={isViewOnly ? 'Student Portal (Reference Access)' : 'Student Portal'}
        navItems={isViewOnly ? VIEW_ONLY_NAV_ITEMS : FULL_NAV_ITEMS}
        activeId={activeId}
        onSelect={setActiveId}
        onLogout={handleLogout}
        pageTitle="Dashboard"
        user={{ name: student?.name || user?.name, idNumber: studentId }}
      >
        {isViewOnly && (
          <div className="mb-5 text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-4 py-3">
            This account has reference-only access — results, timetable, and the academic calendar. Payments and
            course registration aren't available here. Contact the Department Registrar if this seems wrong.
          </div>
        )}
        {sections[activeId]}
      </DashboardShell>
      <ChatbotWidget
        theme={THEME.student}
        respond={respond}
        greeting={`Hi ${student?.name?.split(' ')[0] || 'there'}! ${isViewOnly ? 'Ask me about your results, timetable, or calendar.' : 'Ask me about your payments, registration, timetable, or results.'}`}
      />
    </>
  )
}
