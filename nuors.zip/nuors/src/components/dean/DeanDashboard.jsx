import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import DashboardShell from '../layout/DashboardShell.jsx'
import { useAuth } from '../../context/AuthContext.jsx'
import { useDataStore } from '../../context/DataStoreContext.jsx'
import { THEME } from '../../theme.js'

import Overview from './sections/Overview.jsx'
import PendingApprovals from './sections/PendingApprovals.jsx'
import ApprovedRegistrations from './sections/ApprovedRegistrations.jsx'
import RejectedRegistrations from './sections/RejectedRegistrations.jsx'
import FacultyOverview from './sections/FacultyOverview.jsx'
import Reports from './sections/Reports.jsx'

const STAGE = 'dean'
const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'pending', label: 'Pending Approvals', icon: 'pending' },
  { id: 'approved', label: 'Approved Registrations', icon: 'approved' },
  { id: 'rejected', label: 'Rejected Registrations', icon: 'rejected' },
  { id: 'faculty', label: 'Faculty Overview', icon: 'school' },
  { id: 'reports', label: 'Reports', icon: 'reports' }
]

export default function DeanDashboard() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const store = useDataStore()
  const [activeId, setActiveId] = useState('dashboard')

  const forms = store.forms
  const actionable = forms.filter((f) => store.canSignStage(f, STAGE) && f.stages[STAGE].status === 'Pending')
  const approved = forms.filter((f) => f.stages[STAGE].status === 'Approved')
  const rejected = forms.filter((f) => f.stages[STAGE].status === 'Rejected')
  const notYetReady = forms.filter((f) => !store.canSignStage(f, STAGE) && f.stages[STAGE].status === 'Pending')

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const studentName = (id) => store.getStudent(id)?.name || id

  const decide = (form, decision) => {
    if (decision === 'Rejected') {
      const reason = window.prompt(`Reason for rejecting ${form.fsNo} (flags HOD for re-verification):`)
      if (!reason) return
      store.signStage(form.id, STAGE, 'Rejected', reason)
    } else {
      store.signStage(form.id, STAGE, 'Approved')
    }
  }

  const toggleHold = (form) => store.holdForm(form.id, !form.hold)

  const facultyCounts = {}
  store.students.forEach((s) => {
    facultyCounts[s.school] = (facultyCounts[s.school] || 0) + 1
  })
  const trendData = Object.entries(facultyCounts).map(([name, value]) => ({ name, value }))

  const sharedProps = {
    forms, actionable, approved, rejected, notYetReady,
    studentName, getStudent: store.getStudent, decide, toggleHold,
    facultyCounts, trendData
  }

  const sections = {
    dashboard: <Overview {...sharedProps} />,
    pending: <PendingApprovals {...sharedProps} />,
    approved: <ApprovedRegistrations {...sharedProps} />,
    rejected: <RejectedRegistrations {...sharedProps} />,
    faculty: <FacultyOverview {...sharedProps} />,
    reports: <Reports {...sharedProps} />
  }

  return (
    <DashboardShell
      theme={THEME.dean}
      officeLabel="Dean's Office"
      navItems={NAV_ITEMS}
      activeId={activeId}
      onSelect={setActiveId}
      onLogout={handleLogout}
      pageTitle="Dean Dashboard"
      user={{ name: user?.name, idNumber: user?.idNumber }}
    >
      {sections[activeId]}
    </DashboardShell>
  )
}
