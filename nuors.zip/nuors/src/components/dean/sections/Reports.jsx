import Card from '../../common/Card.jsx'

export default function Reports({ approved, actionable, notYetReady, rejected }) {
  return (
    <Card title="Reports">
      <p className="text-sm text-gray-500">
        Approved: {approved.length} · Pending: {actionable.length + notYetReady.length} · Rejected: {rejected.length}
      </p>
    </Card>
  )
}
