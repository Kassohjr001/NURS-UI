import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'

export default function FacultyOverview({ facultyCounts }) {
  return (
    <Card title="Faculty Overview">
      <DataTable
        columns={[{ key: 'school', label: 'School' }, { key: 'count', label: 'Students' }]}
        rows={Object.entries(facultyCounts).map(([school, count]) => ({ school, count }))}
      />
    </Card>
  )
}
