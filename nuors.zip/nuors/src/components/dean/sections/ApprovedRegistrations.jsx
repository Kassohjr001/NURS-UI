import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildQueueColumns } from './columns.jsx'

export default function ApprovedRegistrations({ approved, studentName, getStudent }) {
  const columns = buildQueueColumns({ stage: 'dean', showActions: false, studentName, getStudent })
  return (
    <Card title="Approved Registrations">
      <DataTable columns={columns} rows={approved} />
    </Card>
  )
}
