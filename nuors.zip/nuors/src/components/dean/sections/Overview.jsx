import StatCard from '../../common/StatCard.jsx'
import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { MiniLineChart } from '../../common/Charts.jsx'
import { THEME } from '../../../theme.js'
import { buildQueueColumns } from './columns.jsx'

export default function Overview({ forms, actionable, approved, rejected, facultyCounts, trendData, studentName, getStudent, decide, toggleHold }) {
  const columns = buildQueueColumns({ stage: 'dean', showActions: true, decide, toggleHold, studentName, getStudent })

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Students Registered" value={forms.length} icon="users" color={THEME.dean.accent} />
        <StatCard label="Pending Approvals" value={actionable.length} icon="pending" color="#f59e0b" />
        <StatCard label="Approved" value={approved.length} icon="approved" color="#22c55e" />
        <StatCard label="Rejected" value={rejected.length} icon="rejected" color="#ef4444" />
      </div>

      <Card title="Pending Approvals">
        <DataTable columns={columns} rows={actionable} emptyText="No registrations awaiting your approval right now." />
      </Card>

      <div className="grid md:grid-cols-2 gap-5">
        <Card title="Faculty Overview">
          <DataTable
            columns={[{ key: 'school', label: 'School' }, { key: 'count', label: 'Students' }]}
            rows={Object.entries(facultyCounts).map(([school, count]) => ({ school, count }))}
          />
        </Card>
        <Card title="Approval Trend">
          <MiniLineChart data={trendData} color={THEME.dean.accent} />
        </Card>
      </div>
    </div>
  )
}
