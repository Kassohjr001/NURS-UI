import { Check } from 'lucide-react'

export default function ProgressStepper({ steps, accentColor = '#0f5e59' }) {
  const completedCount = steps.filter((s) => s.done).length
  const percent = Math.round((completedCount / steps.length) * 100)

  return (
    <div>
      <div className="flex items-center">
        {steps.map((step, i) => (
          <div key={step.label} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-semibold"
                style={{ background: step.done ? accentColor : '#d1d5db' }}
              >
                {step.done ? <Check size={15} /> : i + 1}
              </div>
              <p className="text-[11px] text-gray-500 mt-1.5 text-center w-20 leading-tight">{step.label}</p>
            </div>
            {i < steps.length - 1 && (
              <div className="flex-1 h-0.5 mb-5 mx-1" style={{ background: step.done ? accentColor : '#e5e7eb' }} />
            )}
          </div>
        ))}
      </div>
      <p className="text-right text-xs font-semibold mt-2" style={{ color: accentColor }}>
        {percent}% Completed
      </p>
    </div>
  )
}
