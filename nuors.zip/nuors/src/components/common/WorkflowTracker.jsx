import { Check, Clock, AlertTriangle, X } from 'lucide-react'

// Priority: a flagged stage (something downstream got rejected and sent it
// back) always wins as "where the process is stuck" over a plain pending
// stage further along, since that's genuinely where attention is needed.
function computeStageStates(stageOrder, stages) {
  const flaggedIndex = stageOrder.findIndex((k) => stages[k].flagged)
  const currentIndex =
    flaggedIndex !== -1 ? flaggedIndex : stageOrder.findIndex((k) => stages[k].status !== 'Approved')

  return stageOrder.map((key, i) => {
    const stage = stages[key]
    if (stage.flagged) return 'flagged'
    if (stage.status === 'Rejected') return 'rejected'
    if (stage.status === 'Approved') return 'done'
    if (i === currentIndex) return 'current'
    return 'future'
  })
}

export function getWorkflowSummary(stageOrder, stages, stageLabel) {
  const flaggedKey = stageOrder.find((k) => stages[k].flagged)
  if (flaggedKey) {
    return {
      state: 'flagged',
      message: `${stageLabel[flaggedKey]} needs to re-verify this — ${stages[flaggedKey].flagNote || 'flagged by a later office.'}`
    }
  }
  const rejectedKey = stageOrder.find((k) => stages[k].status === 'Rejected')
  if (rejectedKey) {
    return { state: 'rejected', message: `Rejected by ${stageLabel[rejectedKey]} — ${stages[rejectedKey].reason}` }
  }
  const pendingKey = stageOrder.find((k) => stages[k].status !== 'Approved')
  if (pendingKey) {
    return { state: 'pending', message: `Currently awaiting ${stageLabel[pendingKey]} approval.` }
  }
  return { state: 'complete', message: 'Fully signed — distributed to Exams, Finance, and Department offices.' }
}

const STATE_STYLES = {
  done: { bg: '#16a34a', ring: false, Icon: Check },
  current: { bg: '#f59e0b', ring: true, Icon: Clock },
  flagged: { bg: '#ea580c', ring: true, Icon: AlertTriangle },
  rejected: { bg: '#dc2626', ring: false, Icon: X },
  future: { bg: '#d1d5db', ring: false, Icon: null }
}

const BANNER_STYLES = {
  complete: 'bg-green-50 text-green-700 border-green-200',
  pending: 'bg-amber-50 text-amber-700 border-amber-200',
  flagged: 'bg-orange-50 text-orange-700 border-orange-200',
  rejected: 'bg-red-50 text-red-700 border-red-200'
}

export default function WorkflowTracker({ stageOrder, stages, stageLabel, hold }) {
  const states = computeStageStates(stageOrder, stages)
  const summary = hold
    ? { state: 'flagged', message: 'This registration has been placed on hold for review. No stage can move forward or backward until it is resumed.' }
    : getWorkflowSummary(stageOrder, stages, stageLabel)

  return (
    <div>
      <div className="flex items-center">
        {stageOrder.map((key, i) => {
          const state = states[i]
          const style = STATE_STYLES[state]
          const stage = stages[key]
          return (
            <div key={key} className="flex items-center flex-1 last:flex-none">
              <div className="flex flex-col items-center w-20">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-semibold"
                  style={{ background: style.bg, boxShadow: style.ring ? `0 0 0 4px ${style.bg}33` : 'none' }}
                >
                  {style.Icon ? <style.Icon size={16} /> : i + 1}
                </div>
                <p className="text-[11px] text-gray-600 mt-1.5 text-center font-medium leading-tight">
                  {stageLabel[key]}
                </p>
                <p className="text-[10px] text-gray-400 text-center leading-tight">{stage.date || '—'}</p>
              </div>
              {i < stageOrder.length - 1 && (
                <div
                  className="flex-1 h-0.5 mb-7 mx-1"
                  style={{ background: state === 'done' ? STATE_STYLES.done.bg : '#e5e7eb' }}
                />
              )}
            </div>
          )
        })}
      </div>

      <div className={`mt-4 text-sm rounded-lg border px-3 py-2.5 ${BANNER_STYLES[summary.state]}`}>
        {summary.message}
      </div>
    </div>
  )
}
