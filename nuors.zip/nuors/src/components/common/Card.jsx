export default function Card({ title, action, children, className = '' }) {
  return (
    <div className={`bg-white rounded-xl border border-gray-200 p-4 md:p-5 ${className}`}>
      {(title || action) && (
        <div className="flex items-center justify-between mb-3">
          {title && <h3 className="font-display font-semibold text-gray-800 text-sm">{title}</h3>}
          {action}
        </div>
      )}
      {children}
    </div>
  )
}
