export default function DataTable({ columns, rows, emptyText = 'Nothing to show here yet.' }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-gray-400 text-xs uppercase border-b border-gray-100">
            {columns.map((col) => (
              <th key={col.key} className="py-2 pr-4 font-medium whitespace-nowrap">
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="py-6 text-center text-gray-400 text-sm">
                {emptyText}
              </td>
            </tr>
          ) : (
            rows.map((row, i) => (
              <tr key={row.id || i} className="border-b border-gray-50 hover:bg-gray-50">
                {columns.map((col) => (
                  <td key={col.key} className="py-3 pr-4 align-middle text-gray-700 whitespace-nowrap">
                    {col.render ? col.render(row) : row[col.key]}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  )
}
