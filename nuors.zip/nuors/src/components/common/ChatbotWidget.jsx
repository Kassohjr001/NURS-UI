import { useState } from 'react'
import { MessageCircle, X, Send } from 'lucide-react'

export default function ChatbotWidget({ theme, respond, greeting }) {
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState([
    { from: 'bot', text: greeting || "Hi! I'm the NUORS assistant. Ask me about your payments, registration status, timetable, or results." }
  ])

  const QUICK_REPLIES = [
    'Where is my registration?',
    'How do I upload a payment slip?',
    'When are results out?',
    'How do I check my timetable?'
  ]

  const send = (text) => {
    const message = (text ?? input).trim()
    if (!message) return
    const botReply = respond(message)
    setMessages((m) => [...m, { from: 'user', text: message }, { from: 'bot', text: botReply }])
    setInput('')
  }

  return (
    <div className="fixed bottom-5 right-5 z-50">
      {open && (
        <div className="w-80 sm:w-96 h-[28rem] bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col overflow-hidden mb-3">
          <div
            className="px-4 py-3 flex items-center justify-between text-white"
            style={{ background: theme.primary }}
          >
            <div>
              <p className="font-display font-semibold text-sm">NUORS Assistant</p>
              <p className="text-xs text-white/70">Here to help with the registration process</p>
            </div>
            <button onClick={() => setOpen(false)} className="text-white/80 hover:text-white">
              <X size={18} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-3 py-3 space-y-2 scrollbar-thin bg-gray-50">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`max-w-[85%] text-sm px-3 py-2 rounded-xl ${
                  m.from === 'bot'
                    ? 'bg-white border border-gray-200 text-gray-700'
                    : 'bg-gray-800 text-white ml-auto'
                }`}
              >
                {m.text}
              </div>
            ))}
          </div>

          <div className="px-3 py-2 flex flex-wrap gap-1.5 border-t border-gray-100">
            {QUICK_REPLIES.map((q) => (
              <button
                key={q}
                onClick={() => send(q)}
                className="text-xs px-2.5 py-1 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200"
              >
                {q}
              </button>
            ))}
          </div>

          <div className="px-3 py-3 flex items-center gap-2 border-t border-gray-100">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send()}
              placeholder="Type your question..."
              className="flex-1 text-sm bg-gray-100 rounded-full px-4 py-2 outline-none"
            />
            <button
              onClick={() => send()}
              className="w-9 h-9 rounded-full flex items-center justify-center text-white shrink-0"
              style={{ background: theme.primary }}
            >
              <Send size={16} />
            </button>
          </div>
        </div>
      )}

      <button
        onClick={() => setOpen((v) => !v)}
        className="w-14 h-14 rounded-full shadow-xl flex items-center justify-center text-white"
        style={{ background: theme.primary }}
      >
        {open ? <X size={22} /> : <MessageCircle size={22} />}
      </button>
    </div>
  )
}
