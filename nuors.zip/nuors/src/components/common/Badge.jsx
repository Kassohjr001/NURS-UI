const STYLES = {
  Approved: 'bg-green-100 text-green-700',
  Pending: 'bg-amber-100 text-amber-700',
  Rejected: 'bg-red-100 text-red-700',
  Hold: 'bg-gray-200 text-gray-600',
  Flagged: 'bg-orange-100 text-orange-700',
  Signed: 'bg-green-100 text-green-700',
  'Fully Signed': 'bg-green-100 text-green-700',
  'In Progress': 'bg-blue-100 text-blue-700'
}

export default function Badge({ status, children }) {
  const cls = STYLES[status] || 'bg-gray-100 text-gray-600'
  return (
    <span className={`px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap ${cls}`}>
      {children || status}
    </span>
  )
}
