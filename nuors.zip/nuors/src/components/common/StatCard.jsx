import { Icon } from './icons.jsx'

export default function StatCard({ label, value, icon, color }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-4 flex items-center justify-between">
      <div>
        <p className="text-xs font-medium text-gray-400 uppercase tracking-wide">{label}</p>
        <p className="text-2xl font-display font-bold text-gray-800 mt-1">{value}</p>
      </div>
      <div
        className="w-11 h-11 rounded-lg flex items-center justify-center"
        style={{ background: `${color}1a`, color }}
      >
        <Icon name={icon} size={20} />
      </div>
    </div>
  )
}
