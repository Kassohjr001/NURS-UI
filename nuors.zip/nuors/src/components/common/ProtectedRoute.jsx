import { Navigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext.jsx'
import { ROLE_LOGIN } from '../../theme.js'

export default function ProtectedRoute({ role, children }) {
  const { user } = useAuth()

  if (!user || user.role !== role) {
    return <Navigate to={ROLE_LOGIN} replace />
  }

  // Every account must set its own password before reaching any dashboard —
  // the temp password Admin assigns at creation is never trusted long-term.
  if (user.mustChangePassword) {
    return <Navigate to="/change-password" replace />
  }

  return children
}
