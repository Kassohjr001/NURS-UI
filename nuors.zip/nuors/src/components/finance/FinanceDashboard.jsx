import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import DashboardShell from '../layout/DashboardShell.jsx'
import { useAuth } from '../../context/AuthContext.jsx'
import { useDataStore } from '../../context/DataStoreContext.jsx'
import { THEME } from '../../theme.js'

import Overview from './sections/Overview.jsx'
import ReceiptGeneration from './sections/ReceiptGeneration.jsx'
import PendingReceipts from './sections/PendingReceipts.jsx'
import ApprovedReceipts from './sections/ApprovedReceipts.jsx'
import RejectedReceipts from './sections/RejectedReceipts.jsx'
import StudentsPayments from './sections/StudentsPayments.jsx'
import Reports from './sections/Reports.jsx'
import FinanceLogs from './sections/FinanceLogs.jsx'

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'generate', label: 'Receipt Generation', icon: 'receipts' },
  { id: 'pending', label: 'Pending Receipts', icon: 'pending' },
  { id: 'approved', label: 'Approved Receipts', icon: 'approved' },
  { id: 'rejected', label: 'Rejected Receipts', icon: 'rejected' },
  { id: 'payments', label: "Students' Payments", icon: 'payments' },
  { id: 'reports', label: 'Reports', icon: 'reports' },
  { id: 'logs', label: 'Finance Logs', icon: 'logs' }
]

export default function FinanceDashboard() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const store = useDataStore()
  const [activeId, setActiveId] = useState('dashboard')

  const slips = store.slips
  const awaitingFinance = slips.filter((s) => s.status === 'Approved' && !s.receiptGenerated)
  const receiptedSlips = slips.filter((s) => s.receiptGenerated)
  const financeRejected = slips.filter((s) => s.financeFlagged)
  const totalRevenue = store.receipts.reduce((sum, r) => sum + r.amount, 0)

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const studentName = (id) => store.getStudent(id)?.name || id

  const decide = (slip, decision) => {
    if (decision === 'Rejected') {
      const reason = window.prompt(`Reason for rejecting receipt conversion for ${slip.id} (this flags Audit):`)
      if (!reason) return
      store.financeReviewSlip(slip.id, 'Rejected', reason)
    } else {
      store.financeReviewSlip(slip.id, 'Approved')
    }
  }

  const toggleHold = (slip) => store.holdSlip(slip.id, !slip.hold)

  const sharedProps = { awaitingFinance, receiptedSlips, financeRejected, receipts: store.receipts, totalRevenue, studentName, decide, toggleHold, slips }

  const sections = {
    dashboard: <Overview {...sharedProps} />,
    generate: <ReceiptGeneration {...sharedProps} />,
    pending: <PendingReceipts {...sharedProps} />,
    approved: <ApprovedReceipts {...sharedProps} />,
    rejected: <RejectedReceipts {...sharedProps} />,
    payments: <StudentsPayments {...sharedProps} />,
    reports: <Reports {...sharedProps} />,
    logs: <FinanceLogs {...sharedProps} />
  }

  return (
    <DashboardShell
      theme={THEME.finance}
      officeLabel="Finance Office"
      navItems={NAV_ITEMS}
      activeId={activeId}
      onSelect={setActiveId}
      onLogout={handleLogout}
      pageTitle="Finance Dashboard"
      user={{ name: user?.name, idNumber: user?.idNumber }}
    >
      {sections[activeId]}
    </DashboardShell>
  )
}
