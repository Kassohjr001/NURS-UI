import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildRejectedColumns } from './columns.jsx'

export default function RejectedReceipts({ financeRejected, studentName }) {
  const columns = buildRejectedColumns({ studentName })
  return (
    <Card title="Rejected Receipts">
      <DataTable columns={columns} rows={financeRejected} />
    </Card>
  )
}
