import Card from '../../common/Card.jsx'

export default function Reports({ totalRevenue, receiptedSlips, awaitingFinance }) {
  return (
    <Card title="Reports">
      <p className="text-sm text-gray-500">
        Total Revenue: Le {totalRevenue.toLocaleString()} · Receipts Issued: {receiptedSlips.length} · Pending: {awaitingFinance.length}
      </p>
    </Card>
  )
}
