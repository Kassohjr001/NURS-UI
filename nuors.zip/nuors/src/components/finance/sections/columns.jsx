import Badge from '../../common/Badge.jsx'

export function buildGenerateColumns({ decide, toggleHold, studentName }) {
  return [
    { key: 'id', label: 'Slip ID' },
    { key: 'studentId', label: 'Student', render: (r) => studentName(r.studentId) },
    { key: 'type', label: 'Type' },
    { key: 'amount', label: 'Amount', render: (r) => `Le ${r.amount.toLocaleString()}` },
    { key: 'status', label: 'Audit Status', render: (r) => <Badge status={r.hold ? 'Hold' : 'Approved'} /> },
    {
      key: 'action',
      label: 'Action',
      render: (r) =>
        r.hold ? (
          <button onClick={() => toggleHold(r)} className="text-xs font-semibold text-gray-700 bg-gray-100 px-2.5 py-1 rounded-md">
            Resume Review
          </button>
        ) : (
          <div className="flex gap-2">
            <button onClick={() => decide(r, 'Approved')} className="text-xs font-semibold text-green-700 bg-green-50 px-2.5 py-1 rounded-md">
              Generate Receipt
            </button>
            <button onClick={() => decide(r, 'Rejected')} className="text-xs font-semibold text-red-700 bg-red-50 px-2.5 py-1 rounded-md">
              Reject
            </button>
            <button onClick={() => toggleHold(r)} className="text-xs font-semibold text-gray-600 bg-gray-100 px-2.5 py-1 rounded-md">
              Hold
            </button>
          </div>
        )
    }
  ]
}

export function buildReceiptColumns({ studentName, receipts }) {
  return [
    { key: 'id', label: 'Slip ID' },
    { key: 'studentId', label: 'Student', render: (r) => studentName(r.studentId) },
    { key: 'amount', label: 'Amount', render: (r) => `Le ${r.amount.toLocaleString()}` },
    { key: 'receipt', label: 'Receipt No.', render: (r) => receipts.find((rec) => rec.slipId === r.id)?.id || '—' }
  ]
}

export function buildRejectedColumns({ studentName }) {
  return [
    { key: 'id', label: 'Slip ID' },
    { key: 'studentId', label: 'Student', render: (r) => studentName(r.studentId) },
    { key: 'reason', label: 'Reason' }
  ]
}

export function buildPaymentColumns({ studentName }) {
  return [
    { key: 'id', label: 'Slip ID' },
    { key: 'studentId', label: 'Student', render: (r) => studentName(r.studentId) },
    { key: 'type', label: 'Type' },
    { key: 'amount', label: 'Amount', render: (r) => `Le ${r.amount.toLocaleString()}` },
    { key: 'status', label: 'Status', render: (r) => <Badge status={r.status} /> }
  ]
}
