import StatCard from '../../common/StatCard.jsx'
import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { MiniLineChart, MiniPieChart, PieLegend } from '../../common/Charts.jsx'
import { THEME } from '../../../theme.js'
import { buildGenerateColumns } from './columns.jsx'

export default function Overview({ awaitingFinance, receiptedSlips, financeRejected, receipts, totalRevenue, studentName, decide, toggleHold }) {
  const columns = buildGenerateColumns({ decide, toggleHold, studentName })

  const pieData = [
    { name: 'Approved', value: receiptedSlips.length },
    { name: 'Pending', value: awaitingFinance.length },
    { name: 'Rejected', value: financeRejected.length }
  ]
  const revenueTrend = receipts.slice().reverse().map((r, i) => ({ name: `#${i + 1}`, value: r.amount }))

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Pending Receipts" value={awaitingFinance.length} icon="pending" color="#f59e0b" />
        <StatCard label="Approved Receipts" value={receiptedSlips.length} icon="approved" color="#22c55e" />
        <StatCard label="Rejected Receipts" value={financeRejected.length} icon="rejected" color="#ef4444" />
        <StatCard label="Total Revenue" value={`Le ${totalRevenue.toLocaleString()}`} icon="revenue" color={THEME.finance.accent} />
      </div>

      <Card title="Pending Receipts">
        <DataTable columns={columns} rows={awaitingFinance.slice(0, 5)} />
      </Card>

      <div className="grid md:grid-cols-2 gap-5">
        <Card title="Revenue Summary (This Semester)">
          <MiniLineChart data={revenueTrend} color={THEME.finance.accent} />
        </Card>
        <Card title="Receipt Summary">
          <MiniPieChart data={pieData} />
          <PieLegend data={pieData} />
        </Card>
      </div>
    </div>
  )
}
