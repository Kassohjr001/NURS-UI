import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildGenerateColumns } from './columns.jsx'

export default function ReceiptGeneration({ awaitingFinance, studentName, decide, toggleHold }) {
  const columns = buildGenerateColumns({ decide, toggleHold, studentName })
  return (
    <Card title="Convert Audited Slips into Receipts">
      <DataTable columns={columns} rows={awaitingFinance} />
    </Card>
  )
}
