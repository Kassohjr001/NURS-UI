import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildReceiptColumns } from './columns.jsx'

export default function ApprovedReceipts({ receiptedSlips, receipts, studentName }) {
  const columns = buildReceiptColumns({ studentName, receipts })
  return (
    <Card title="Approved Receipts">
      <DataTable columns={columns} rows={receiptedSlips} />
    </Card>
  )
}
