import Card from '../../common/Card.jsx'

export default function FinanceLogs({ receipts, studentName }) {
  return (
    <Card title="Finance Logs">
      <ul className="space-y-2 text-sm text-gray-600">
        {receipts.map((r) => (
          <li key={r.id}>
            {r.id} issued to {studentName(r.studentId)} for Le {r.amount.toLocaleString()} on {r.dateIssued}
          </li>
        ))}
      </ul>
    </Card>
  )
}
