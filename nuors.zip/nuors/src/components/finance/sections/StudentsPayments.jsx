import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildPaymentColumns } from './columns.jsx'

export default function StudentsPayments({ slips, studentName }) {
  const columns = buildPaymentColumns({ studentName })
  return (
    <Card title="All Students' Payments">
      <DataTable columns={columns} rows={slips} />
    </Card>
  )
}
