import { useState } from 'react'
import { Menu, X } from 'lucide-react'
import Sidebar from './Sidebar.jsx'
import Topbar from './Topbar.jsx'

export default function DashboardShell({
  theme,
  officeLabel,
  navItems,
  activeId,
  onSelect,
  onLogout,
  pageTitle,
  user,
  children
}) {
  const [mobileOpen, setMobileOpen] = useState(false)

  const handleSelect = (id) => {
    onSelect(id)
    setMobileOpen(false)
  }

  return (
    <div className="flex h-screen w-full bg-gray-100 overflow-hidden">
      <Sidebar
        theme={theme}
        officeLabel={officeLabel}
        navItems={navItems}
        activeId={activeId}
        onSelect={handleSelect}
        onLogout={onLogout}
      />

      {mobileOpen && (
        <div className="fixed inset-0 z-40 bg-black/40" onClick={() => setMobileOpen(false)} />
      )}
      <Sidebar
        theme={theme}
        officeLabel={officeLabel}
        navItems={navItems}
        activeId={activeId}
        onSelect={handleSelect}
        onLogout={onLogout}
        mobile
        open={mobileOpen}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <div className="flex items-center md:hidden bg-white border-b border-gray-200 px-3 py-2">
          <button onClick={() => setMobileOpen((v) => !v)} className="text-gray-600">
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
          <p className="ml-3 font-display font-semibold text-gray-800 text-sm">{officeLabel}</p>
        </div>
        <Topbar title={pageTitle} user={user} theme={theme} />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 scrollbar-thin">{children}</main>
      </div>
    </div>
  )
}
