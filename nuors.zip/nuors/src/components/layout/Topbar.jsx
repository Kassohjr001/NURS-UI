import { Bell, Search } from 'lucide-react'

export default function Topbar({ title, user, theme }) {
  return (
    <header className="h-16 shrink-0 bg-white border-b border-gray-200 flex items-center justify-between px-4 md:px-6">
      <div className="flex items-center gap-2 text-gray-400 bg-gray-100 rounded-lg px-3 py-1.5 w-full max-w-xs">
        <Search size={16} />
        <input
          placeholder="Search anything..."
          className="bg-transparent outline-none text-sm w-full text-gray-600 placeholder:text-gray-400"
        />
      </div>

      <div className="flex items-center gap-4 ml-4">
        <button className="relative text-gray-500 hover:text-gray-700">
          <Bell size={20} />
          <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-red-500" />
        </button>
        <div className="flex items-center gap-2">
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center text-white font-display font-semibold text-sm"
            style={{ background: theme.primary }}
          >
            {(user?.name || '?').charAt(0)}
          </div>
          <div className="hidden sm:block leading-tight">
            <p className="text-sm font-semibold text-gray-800">{user?.name}</p>
            <p className="text-xs text-gray-400">{user?.idNumber}</p>
          </div>
        </div>
      </div>
    </header>
  )
}
