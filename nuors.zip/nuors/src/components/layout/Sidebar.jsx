import { Icon } from '../common/icons.jsx'

export default function Sidebar({ theme, officeLabel, navItems, activeId, onSelect, onLogout, mobile, open }) {
  const baseClasses = mobile
    ? `fixed inset-y-0 left-0 w-64 z-50 transform transition-transform duration-200 ${open ? 'translate-x-0' : '-translate-x-full'}`
    : 'hidden md:flex md:w-64'

  return (
    <aside
      className={`${baseClasses} flex flex-col shrink-0 text-white`}
      style={{ background: `linear-gradient(180deg, ${theme.primary} 0%, ${theme.primaryDark} 100%)` }}
    >
      <div className="px-5 py-6 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-lg bg-white/15 flex items-center justify-center font-display font-bold text-sm">
            NU
          </div>
          <div>
            <p className="font-display font-semibold text-sm leading-tight">Njala University</p>
            <p className="text-xs text-white/70 leading-tight">{officeLabel}</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto py-3 scrollbar-thin">
        {navItems.map((item) => {
          const active = item.id === activeId
          return (
            <button
              key={item.id}
              onClick={() => onSelect(item.id)}
              className={`w-full flex items-center gap-3 px-5 py-2.5 text-sm transition-colors text-left ${
                active ? 'bg-white/15 font-semibold' : 'text-white/80 hover:bg-white/10'
              }`}
              style={active ? { borderRight: `3px solid ${theme.accent}` } : undefined}
            >
              <Icon name={item.icon} size={17} />
              <span>{item.label}</span>
            </button>
          )
        })}
      </nav>

      <div className="px-3 py-4 border-t border-white/10">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 text-sm rounded-lg text-white/80 hover:bg-white/10 transition-colors"
        >
          <Icon name="logout" size={17} />
          Logout
        </button>
      </div>
    </aside>
  )
}
