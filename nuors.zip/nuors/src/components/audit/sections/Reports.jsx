import Card from '../../common/Card.jsx'

export default function Reports({ slips, pending, approved, rejected }) {
  return (
    <Card title="Reports">
      <p className="text-sm text-gray-500">
        Approved: {approved.length} · Pending: {pending.length} · Rejected: {rejected.length} · Total: {slips.length}
      </p>
    </Card>
  )
}
