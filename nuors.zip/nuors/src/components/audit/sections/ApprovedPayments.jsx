import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildSlipColumns } from './slipColumns.jsx'

export default function ApprovedPayments({ approved, studentName }) {
  const columns = buildSlipColumns({ showActions: false, studentName })
  return (
    <Card title="Approved Payments">
      <DataTable columns={columns} rows={approved} />
    </Card>
  )
}
