import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildSlipColumns } from './slipColumns.jsx'

export default function PendingReviews({ pending, studentName, decide, toggleHold }) {
  const columns = buildSlipColumns({ showActions: true, decide, toggleHold, studentName })
  return (
    <Card title="Pending Reviews">
      <DataTable columns={columns} rows={pending} />
    </Card>
  )
}
