import Card from '../../common/Card.jsx'

export default function AuditLogs({ slips, studentName }) {
  return (
    <Card title="Audit Logs">
      <ul className="space-y-2 text-sm text-gray-600">
        {slips.map((s) => (
          <li key={s.id}>
            {s.id} — {studentName(s.studentId)} — <span className="font-semibold">{s.status}</span>
            {s.dateSubmitted ? ` on ${s.dateSubmitted}` : ''}
          </li>
        ))}
      </ul>
    </Card>
  )
}
