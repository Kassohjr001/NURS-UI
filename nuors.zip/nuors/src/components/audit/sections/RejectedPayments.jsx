import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildSlipColumns } from './slipColumns.jsx'

export default function RejectedPayments({ rejected, studentName }) {
  const columns = buildSlipColumns({ showActions: false, studentName })
  return (
    <Card title="Rejected Payments">
      <DataTable columns={columns} rows={rejected} />
    </Card>
  )
}
