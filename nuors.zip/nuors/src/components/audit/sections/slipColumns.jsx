import Badge from '../../common/Badge.jsx'

// Shared column builder for every slip table on the Audit dashboard. Kept in
// one place so Approve/Reject/Hold behavior stays identical across views.
export function buildSlipColumns({ showActions, decide, toggleHold, studentName }) {
  return [
    { key: 'id', label: 'Slip ID' },
    { key: 'studentId', label: 'Student', render: (r) => studentName(r.studentId) },
    { key: 'type', label: 'Type' },
    { key: 'amount', label: 'Amount', render: (r) => `Le ${r.amount.toLocaleString()}` },
    { key: 'dateSubmitted', label: 'Date Submitted' },
    {
      key: 'status',
      label: 'Status',
      render: (r) => (
        <div className="flex items-center gap-1.5">
          <Badge status={r.hold ? 'Hold' : r.financeFlagged ? 'Flagged' : r.status} />
        </div>
      )
    },
    ...(showActions
      ? [
          {
            key: 'action',
            label: 'Action',
            render: (r) =>
              r.hold ? (
                <button
                  onClick={() => toggleHold(r)}
                  className="text-xs font-semibold text-gray-700 bg-gray-100 px-2.5 py-1 rounded-md"
                >
                  Resume Review
                </button>
              ) : (
                <div className="flex gap-2">
                  <button
                    onClick={() => decide(r, 'Approved')}
                    className="text-xs font-semibold text-green-700 bg-green-50 px-2.5 py-1 rounded-md"
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => decide(r, 'Rejected')}
                    className="text-xs font-semibold text-red-700 bg-red-50 px-2.5 py-1 rounded-md"
                  >
                    Reject
                  </button>
                  <button
                    onClick={() => toggleHold(r)}
                    className="text-xs font-semibold text-gray-600 bg-gray-100 px-2.5 py-1 rounded-md"
                  >
                    Hold
                  </button>
                </div>
              )
          }
        ]
      : [{ key: 'reason', label: 'Note', render: (r) => r.reason || '—' }])
  ]
}
