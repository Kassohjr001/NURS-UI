import StatCard from '../../common/StatCard.jsx'
import Card from '../../common/Card.jsx'
import Badge from '../../common/Badge.jsx'
import DataTable from '../../common/DataTable.jsx'
import { MiniPieChart, PieLegend } from '../../common/Charts.jsx'
import { THEME } from '../../../theme.js'
import { buildSlipColumns } from './slipColumns.jsx'

export default function Overview({ slips, pending, approved, rejected, studentName, decide, toggleHold }) {
  const columns = buildSlipColumns({ showActions: true, decide, toggleHold, studentName })

  const pieData = [
    { name: 'Approved', value: approved.length },
    { name: 'Pending', value: pending.length },
    { name: 'Rejected', value: rejected.length }
  ]

  const recentActivity = [...slips]
    .filter((s) => s.status !== 'Pending')
    .sort((a, b) => (a.dateSubmitted < b.dateSubmitted ? 1 : -1))
    .slice(0, 5)

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Requests" value={slips.length} icon="data" color={THEME.audit.accent} />
        <StatCard label="Pending Reviews" value={pending.length} icon="pending" color="#f59e0b" />
        <StatCard label="Approved Payments" value={approved.length} icon="approved" color="#22c55e" />
        <StatCard label="Rejected Payments" value={rejected.length} icon="rejected" color="#ef4444" />
      </div>

      <Card title="Pending Reviews">
        <DataTable columns={columns} rows={pending.slice(0, 5)} />
      </Card>

      <div className="grid md:grid-cols-2 gap-5">
        <Card title="Verification Summary">
          <MiniPieChart data={pieData} />
          <PieLegend data={pieData} />
        </Card>
        <Card title="Recent Activity">
          <ul className="space-y-3">
            {recentActivity.map((s) => (
              <li key={s.id} className="text-sm flex items-center justify-between">
                <span className="text-gray-700">{studentName(s.studentId)} — {s.id}</span>
                <Badge status={s.status} />
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  )
}
