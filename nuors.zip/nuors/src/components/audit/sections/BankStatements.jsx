import Card from '../../common/Card.jsx'

export default function BankStatements() {
  return (
    <Card title="Bank Statements">
      <p className="text-sm text-gray-500">
        This is where uploaded bank statement extracts would be reconciled against submitted slips. Connect a
        real bank feed or statement upload here in production.
      </p>
    </Card>
  )
}
