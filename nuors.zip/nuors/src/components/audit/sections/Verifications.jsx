import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildSlipColumns } from './slipColumns.jsx'

export default function Verifications({ slips, studentName, decide, toggleHold }) {
  const columns = buildSlipColumns({ showActions: true, decide, toggleHold, studentName })
  return (
    <Card title="All Payment Verifications">
      <DataTable columns={columns} rows={slips} />
    </Card>
  )
}
