import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import DashboardShell from '../layout/DashboardShell.jsx'
import { useAuth } from '../../context/AuthContext.jsx'
import { useDataStore } from '../../context/DataStoreContext.jsx'
import { THEME } from '../../theme.js'

import Overview from './sections/Overview.jsx'
import Verifications from './sections/Verifications.jsx'
import PendingReviews from './sections/PendingReviews.jsx'
import ApprovedPayments from './sections/ApprovedPayments.jsx'
import RejectedPayments from './sections/RejectedPayments.jsx'
import BankStatements from './sections/BankStatements.jsx'
import Reports from './sections/Reports.jsx'
import AuditLogs from './sections/AuditLogs.jsx'

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'verifications', label: 'Payment Verifications', icon: 'review' },
  { id: 'pending', label: 'Pending Reviews', icon: 'pending' },
  { id: 'approved', label: 'Approved Payments', icon: 'approved' },
  { id: 'rejected', label: 'Rejected Payments', icon: 'rejected' },
  { id: 'bank', label: 'Bank Statements', icon: 'bank' },
  { id: 'reports', label: 'Reports', icon: 'reports' },
  { id: 'logs', label: 'Audit Logs', icon: 'logs' }
]

export default function AuditDashboard() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const store = useDataStore()
  const [activeId, setActiveId] = useState('dashboard')

  const slips = store.slips
  const pending = slips.filter((s) => s.status === 'Pending')
  const approved = slips.filter((s) => s.status === 'Approved')
  const rejected = slips.filter((s) => s.status === 'Rejected')

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const decide = (slip, decision) => {
    if (decision === 'Rejected') {
      const reason = window.prompt(`Reason for rejecting ${slip.id}:`)
      if (!reason) return
      store.auditReviewSlip(slip.id, 'Rejected', reason)
    } else {
      store.auditReviewSlip(slip.id, 'Approved')
    }
  }

  const toggleHold = (slip) => store.holdSlip(slip.id, !slip.hold)
  const studentName = (id) => store.getStudent(id)?.name || id

  const sections = {
    dashboard: <Overview slips={slips} pending={pending} approved={approved} rejected={rejected} studentName={studentName} decide={decide} toggleHold={toggleHold} />,
    verifications: <Verifications slips={slips} studentName={studentName} decide={decide} toggleHold={toggleHold} />,
    pending: <PendingReviews pending={pending} studentName={studentName} decide={decide} toggleHold={toggleHold} />,
    approved: <ApprovedPayments approved={approved} studentName={studentName} />,
    rejected: <RejectedPayments rejected={rejected} studentName={studentName} />,
    bank: <BankStatements />,
    reports: <Reports slips={slips} pending={pending} approved={approved} rejected={rejected} />,
    logs: <AuditLogs slips={slips} studentName={studentName} />
  }

  return (
    <DashboardShell
      theme={THEME.audit}
      officeLabel="Audit Office"
      navItems={NAV_ITEMS}
      activeId={activeId}
      onSelect={setActiveId}
      onLogout={handleLogout}
      pageTitle="Audit Dashboard"
      user={{ name: user?.name, idNumber: user?.idNumber }}
    >
      {sections[activeId]}
    </DashboardShell>
  )
}
