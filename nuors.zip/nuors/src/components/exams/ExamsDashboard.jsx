import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import DashboardShell from '../layout/DashboardShell.jsx'
import { useAuth } from '../../context/AuthContext.jsx'
import { useDataStore } from '../../context/DataStoreContext.jsx'
import { THEME } from '../../theme.js'
import { overallStatus } from './sections/helpers.jsx'

import Overview from './sections/Overview.jsx'
import Registrations from './sections/Registrations.jsx'
import TimetableManagement from './sections/TimetableManagement.jsx'
import ResultsManagement from './sections/ResultsManagement.jsx'
import AcademicCalendar from './sections/AcademicCalendar.jsx'
import Reports from './sections/Reports.jsx'
import Settings from './sections/Settings.jsx'

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'registrations', label: 'Registrations', icon: 'forms' },
  { id: 'timetable', label: 'Timetable Management', icon: 'calendar' },
  { id: 'results', label: 'Results Management', icon: 'results' },
  { id: 'calendar', label: 'Academic Calendar', icon: 'calendar' },
  { id: 'reports', label: 'Reports', icon: 'reports' },
  { id: 'settings', label: 'Settings', icon: 'settings' }
]

export default function ExamsDashboard() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const store = useDataStore()
  const [activeId, setActiveId] = useState('dashboard')

  const forms = store.forms
  const completed = forms.filter((f) => overallStatus(f) === 'Fully Signed')
  const pending = forms.filter((f) => overallStatus(f) === 'In Progress')

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const studentName = (id) => store.getStudent(id)?.name || id

  const sharedProps = {
    forms, completed, pending, studentName,
    timetable: store.timetable, addTimetableEntry: store.addTimetableEntry,
    calendarEvents: store.calendarEvents, addCalendarEvent: store.addCalendarEvent,
    resultsPublished: store.resultsPublished, publishResults: store.publishResults
  }

  const sections = {
    dashboard: <Overview {...sharedProps} />,
    registrations: <Registrations {...sharedProps} />,
    timetable: <TimetableManagement {...sharedProps} />,
    results: <ResultsManagement {...sharedProps} />,
    calendar: <AcademicCalendar {...sharedProps} />,
    reports: <Reports {...sharedProps} />,
    settings: <Settings />
  }

  return (
    <DashboardShell
      theme={THEME.exams}
      officeLabel="Examinations Office"
      navItems={NAV_ITEMS}
      activeId={activeId}
      onSelect={setActiveId}
      onLogout={handleLogout}
      pageTitle="Exams Office Dashboard"
      user={{ name: user?.name, idNumber: user?.idNumber }}
    >
      {sections[activeId]}
    </DashboardShell>
  )
}
