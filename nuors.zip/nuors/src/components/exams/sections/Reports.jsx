import Card from '../../common/Card.jsx'

export default function Reports({ completed, pending, forms }) {
  return (
    <Card title="Reports">
      <p className="text-sm text-gray-500">
        Fully Signed: {completed.length} · In Progress: {pending.length} · Total: {forms.length}
      </p>
    </Card>
  )
}
