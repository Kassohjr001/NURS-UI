import StatCard from '../../common/StatCard.jsx'
import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { DEPARTMENTS } from '../../../data/mockData.js'
import { THEME } from '../../../theme.js'
import { buildRegistrationColumns } from './helpers.jsx'

export default function Overview({ forms, completed, pending, studentName }) {
  const columns = buildRegistrationColumns({ studentName })
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Registered Students" value={forms.length} icon="users" color={THEME.exams.accent} />
        <StatCard label="Completed Registrations" value={completed.length} icon="approved" color="#22c55e" />
        <StatCard label="Pending Registrations" value={pending.length} icon="pending" color="#f59e0b" />
        <StatCard label="Departments" value={DEPARTMENTS.length} icon="department" color="#a855f7" />
      </div>

      <Card title="All Registrations">
        <DataTable columns={columns} rows={forms.slice(0, 6)} />
      </Card>
    </div>
  )
}
