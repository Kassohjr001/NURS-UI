import { useState } from 'react'
import { CalendarPlus } from 'lucide-react'
import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'

export default function TimetableManagement({ timetable, addTimetableEntry }) {
  const [course, setCourse] = useState('')
  const [date, setDate] = useState('')
  const [time, setTime] = useState('')
  const [venue, setVenue] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!course || !date) return
    addTimetableEntry({ course, date, time, venue })
    setCourse(''); setDate(''); setTime(''); setVenue('')
  }

  return (
    <div className="space-y-5">
      <Card title="Upload / Add Timetable Entry">
        <form onSubmit={handleSubmit} className="grid sm:grid-cols-5 gap-3 items-end">
          <input value={course} onChange={(e) => setCourse(e.target.value)} placeholder="Course (e.g. CSC 320)" className="border border-gray-200 rounded-lg px-3 py-2 text-sm sm:col-span-2" />
          <input value={date} onChange={(e) => setDate(e.target.value)} placeholder="Date" type="date" className="border border-gray-200 rounded-lg px-3 py-2 text-sm" />
          <input value={time} onChange={(e) => setTime(e.target.value)} placeholder="Time" className="border border-gray-200 rounded-lg px-3 py-2 text-sm" />
          <input value={venue} onChange={(e) => setVenue(e.target.value)} placeholder="Venue" className="border border-gray-200 rounded-lg px-3 py-2 text-sm" />
          <button type="submit" className="flex items-center justify-center gap-2 bg-purple-700 text-white text-sm font-semibold rounded-lg py-2.5 sm:col-span-5">
            <CalendarPlus size={15} /> Publish Timetable Entry (notifies students)
          </button>
        </form>
      </Card>
      <Card title="Current Timetable">
        <DataTable
          columns={[
            { key: 'course', label: 'Course' },
            { key: 'date', label: 'Date' },
            { key: 'time', label: 'Time' },
            { key: 'venue', label: 'Venue' }
          ]}
          rows={timetable}
        />
      </Card>
    </div>
  )
}
