import Card from '../../common/Card.jsx'

export default function Settings() {
  return (
    <Card title="Settings">
      <p className="text-sm text-gray-500">Office settings and preferences would live here.</p>
    </Card>
  )
}
