import { Megaphone } from 'lucide-react'
import Card from '../../common/Card.jsx'
import Badge from '../../common/Badge.jsx'
import DataTable from '../../common/DataTable.jsx'
import { DEPARTMENTS } from '../../../data/mockData.js'

export default function ResultsManagement({ completed, resultsPublished, publishResults }) {
  return (
    <Card title="Results Management">
      <p className="text-sm text-gray-500 mb-4">
        Results can only be released to students who are fully paid and fully registered. {completed.length} student(s) currently qualify this semester.
        Even then, nothing shows on a student's Results tab until you publish here.
      </p>
      {resultsPublished ? (
        <div className="flex items-center gap-2 text-sm font-semibold text-green-700 bg-green-50 border border-green-200 rounded-lg px-4 py-2.5 w-fit">
          <Megaphone size={15} /> Results are live — eligible students can see their grades now.
        </div>
      ) : (
        <button
          onClick={publishResults}
          className="flex items-center gap-2 bg-purple-700 text-white text-sm font-semibold rounded-lg px-4 py-2.5"
        >
          <Megaphone size={15} /> Publish Results for This Semester
        </button>
      )}
      <div className="mt-5">
        <DataTable
          columns={[
            { key: 'name', label: 'Department' },
            { key: 'students', label: 'Students' },
            { key: 'resultsPublished', label: 'Published', render: (r) => <Badge status={r.resultsPublished ? 'Approved' : 'Pending'}>{r.resultsPublished ? 'Yes' : 'No'}</Badge> }
          ]}
          rows={DEPARTMENTS}
        />
      </div>
    </Card>
  )
}
