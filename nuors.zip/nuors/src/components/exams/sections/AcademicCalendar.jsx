import { useState } from 'react'
import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'

export default function AcademicCalendar({ calendarEvents, addCalendarEvent }) {
  const [eventTitle, setEventTitle] = useState('')
  const [eventDate, setEventDate] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!eventTitle || !eventDate) return
    addCalendarEvent({ title: eventTitle, date: eventDate })
    setEventTitle(''); setEventDate('')
  }

  return (
    <div className="space-y-5">
      <Card title="Add Calendar Event">
        <form onSubmit={handleSubmit} className="grid sm:grid-cols-4 gap-3 items-end">
          <input value={eventTitle} onChange={(e) => setEventTitle(e.target.value)} placeholder="Event title" className="border border-gray-200 rounded-lg px-3 py-2 text-sm sm:col-span-2" />
          <input value={eventDate} onChange={(e) => setEventDate(e.target.value)} type="date" className="border border-gray-200 rounded-lg px-3 py-2 text-sm" />
          <button type="submit" className="bg-purple-700 text-white text-sm font-semibold rounded-lg py-2.5">
            Add Event
          </button>
        </form>
      </Card>
      <Card title="Academic Calendar">
        <DataTable columns={[{ key: 'title', label: 'Event' }, { key: 'date', label: 'Date' }]} rows={calendarEvents} />
      </Card>
    </div>
  )
}
