import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildRegistrationColumns } from './helpers.jsx'

export default function Registrations({ forms, studentName }) {
  const columns = buildRegistrationColumns({ studentName })
  return (
    <Card title="All Registrations">
      <DataTable columns={columns} rows={forms} />
    </Card>
  )
}
