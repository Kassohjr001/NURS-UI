import Badge from '../../common/Badge.jsx'
import { STAGE_ORDER } from '../../../context/DataStoreContext.jsx'

export function overallStatus(form) {
  const statuses = STAGE_ORDER.map((k) => form.stages[k].status)
  if (statuses.every((s) => s === 'Approved')) return 'Fully Signed'
  if (statuses.includes('Rejected')) return 'Rejected'
  return 'In Progress'
}

export function buildRegistrationColumns({ studentName }) {
  return [
    { key: 'id', label: 'Form', render: (r) => r.fsNo },
    { key: 'student', label: 'Student', render: (r) => studentName(r.studentId) },
    { key: 'courses', label: 'Courses', render: (r) => r.courseCodes.join(', ') },
    ...STAGE_ORDER.map((k) => ({
      key: k,
      label: k.charAt(0).toUpperCase() + k.slice(1),
      render: (r) => <Badge status={r.stages[k].status} />
    })),
    { key: 'overall', label: 'Overall', render: (r) => <Badge status={overallStatus(r)} /> }
  ]
}
