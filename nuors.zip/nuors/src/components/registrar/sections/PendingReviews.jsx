import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildPendingColumns } from './columns.jsx'

export default function PendingReviews({ actionable, studentName, getStudent, decide, toggleHold }) {
  const columns = buildPendingColumns({ studentName, getStudent, decide, toggleHold })
  return (
    <Card title="Pending Reviews">
      <DataTable columns={columns} rows={actionable} />
    </Card>
  )
}
