import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { buildReviewedColumns } from './columns.jsx'

export default function ReviewedStudents({ reviewedToday, studentName, getStudent }) {
  const columns = buildReviewedColumns({ studentName, getStudent })
  return (
    <Card title="Reviewed Students">
      <DataTable columns={columns} rows={reviewedToday} />
    </Card>
  )
}
