import Badge from '../../common/Badge.jsx'

export function buildPendingColumns({ studentName, getStudent, decide, toggleHold }) {
  return [
    { key: 'id', label: 'Student ID', render: (r) => r.studentId },
    { key: 'name', label: 'Student Name', render: (r) => studentName(r.studentId) },
    { key: 'programme', label: 'Programme', render: (r) => getStudent(r.studentId)?.programme },
    { key: 'credits', label: 'Credits', render: (r) => r.courseCodes.length * 3 },
    {
      key: 'action',
      label: 'Action',
      render: (r) =>
        r.hold ? (
          <div className="flex items-center gap-2">
            <Badge status="Hold" />
            <button onClick={() => toggleHold(r)} className="text-xs font-semibold text-gray-700 bg-gray-100 px-2.5 py-1 rounded-md">
              Resume
            </button>
          </div>
        ) : (
          <div className="flex gap-2">
            <button onClick={() => decide(r, 'Approved')} className="text-xs font-semibold text-green-700 bg-green-50 px-2.5 py-1 rounded-md">
              Approve
            </button>
            <button onClick={() => decide(r, 'Rejected')} className="text-xs font-semibold text-red-700 bg-red-50 px-2.5 py-1 rounded-md">
              Reject
            </button>
            <button onClick={() => toggleHold(r)} className="text-xs font-semibold text-gray-600 bg-gray-100 px-2.5 py-1 rounded-md">
              Hold
            </button>
          </div>
        )
    }
  ]
}

export function buildReviewedColumns({ studentName, getStudent }) {
  return [
    { key: 'id', label: 'Student ID', render: (r) => r.studentId },
    { key: 'name', label: 'Student Name', render: (r) => studentName(r.studentId) },
    { key: 'programme', label: 'Programme', render: (r) => getStudent(r.studentId)?.programme },
    { key: 'credits', label: 'Credits', render: (r) => r.courseCodes.length * 3 },
    { key: 'status', label: 'Status', render: (r) => <Badge status={r.stages.registrar.status} /> }
  ]
}
