import StatCard from '../../common/StatCard.jsx'
import Card from '../../common/Card.jsx'
import DataTable from '../../common/DataTable.jsx'
import { THEME } from '../../../theme.js'
import { buildPendingColumns } from './columns.jsx'

export default function Overview({ actionable, approvedToday, rejectedToday, reviewedToday, notYetReady, studentName, getStudent, decide, toggleHold }) {
  const columns = buildPendingColumns({ studentName, getStudent, decide, toggleHold })
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Pending Reviews" value={actionable.length} icon="pending" color="#f59e0b" />
        <StatCard label="Approved Today" value={approvedToday.length} icon="approved" color="#22c55e" />
        <StatCard label="Rejected Today" value={rejectedToday.length} icon="rejected" color="#ef4444" />
        <StatCard label="Total Reviewed" value={reviewedToday.length} icon="data" color={THEME.registrar.accent} />
      </div>

      <Card title="Pending Reviews">
        <DataTable columns={columns} rows={actionable} emptyText="No final clearances awaiting your review right now." />
        {notYetReady.length > 0 && (
          <p className="text-xs text-gray-400 mt-3">
            {notYetReady.length} more form(s) are still moving through Finance, Audit, HOD, or Dean before reaching you.
          </p>
        )}
      </Card>
    </div>
  )
}
