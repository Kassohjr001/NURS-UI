import Card from '../../common/Card.jsx'

export default function Reports({ approvedToday, actionable, notYetReady, rejectedToday }) {
  return (
    <Card title="Reports">
      <p className="text-sm text-gray-500">
        Approved: {approvedToday.length} · Pending: {actionable.length + notYetReady.length} · Rejected: {rejectedToday.length}
      </p>
    </Card>
  )
}
