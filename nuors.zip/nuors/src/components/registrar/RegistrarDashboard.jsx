import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import DashboardShell from '../layout/DashboardShell.jsx'
import { useAuth } from '../../context/AuthContext.jsx'
import { useDataStore } from '../../context/DataStoreContext.jsx'
import { THEME } from '../../theme.js'

import Overview from './sections/Overview.jsx'
import PendingReviews from './sections/PendingReviews.jsx'
import ReviewedStudents from './sections/ReviewedStudents.jsx'
import Reports from './sections/Reports.jsx'

const STAGE = 'registrar'
const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'pending', label: 'Pending Reviews', icon: 'pending' },
  { id: 'reviewed', label: 'Reviewed Students', icon: 'list' },
  { id: 'reports', label: 'Reports', icon: 'reports' }
]

export default function RegistrarDashboard() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const store = useDataStore()
  const [activeId, setActiveId] = useState('dashboard')

  const forms = store.forms
  const actionable = forms.filter((f) => store.canSignStage(f, STAGE) && f.stages[STAGE].status === 'Pending')
  const reviewedToday = forms.filter((f) => f.stages[STAGE].status !== 'Pending')
  const approvedToday = forms.filter((f) => f.stages[STAGE].status === 'Approved')
  const rejectedToday = forms.filter((f) => f.stages[STAGE].status === 'Rejected')
  const notYetReady = forms.filter((f) => !store.canSignStage(f, STAGE) && f.stages[STAGE].status === 'Pending')

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const studentName = (id) => store.getStudent(id)?.name || id

  const decide = (form, decision) => {
    if (decision === 'Rejected') {
      const reason = window.prompt(`Reason for rejecting final clearance for ${form.fsNo} (flags Dean):`)
      if (!reason) return
      store.signStage(form.id, STAGE, 'Rejected', reason)
    } else {
      store.signStage(form.id, STAGE, 'Approved')
    }
  }

  const toggleHold = (form) => store.holdForm(form.id, !form.hold)

  const sharedProps = {
    actionable, reviewedToday, approvedToday, rejectedToday, notYetReady,
    studentName, getStudent: store.getStudent, decide, toggleHold
  }

  const sections = {
    dashboard: <Overview {...sharedProps} />,
    pending: <PendingReviews {...sharedProps} />,
    reviewed: <ReviewedStudents {...sharedProps} />,
    reports: <Reports {...sharedProps} />
  }

  return (
    <DashboardShell
      theme={THEME.registrar}
      officeLabel="Department Registrar"
      navItems={NAV_ITEMS}
      activeId={activeId}
      onSelect={setActiveId}
      onLogout={handleLogout}
      pageTitle="Department Registrar Dashboard"
      user={{ name: user?.name, idNumber: user?.idNumber }}
    >
      {sections[activeId]}
    </DashboardShell>
  )
}
