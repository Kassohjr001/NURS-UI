import { createContext, useContext, useEffect, useState } from 'react'
import {
  STUDENTS,
  INITIAL_SLIPS,
  INITIAL_RECEIPTS,
  INITIAL_FORMS,
  TIMETABLE,
  CALENDAR_EVENTS,
  INITIAL_ACCOUNTS,
  DEFAULT_TEMP_PASSWORD,
  SEMESTER
} from '../data/mockData.js'

const DataStoreContext = createContext(null)

const STORAGE_KEY = 'nuors_data_v1'

// Order the five signature stages appear on the physical registration form.
// A stage can only be approved once the stage before it is approved, and a
// rejection automatically flags the stage before it for re-verification —
// this is the "self-healing approval chain" described in the project docs.
export const STAGE_ORDER = ['finance', 'audit', 'hod', 'dean', 'registrar']

export const STAGE_LABEL = {
  finance: 'Finance',
  audit: 'Audit',
  hod: 'HOD',
  dean: 'Dean',
  registrar: 'Registrar'
}

function loadInitialState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return JSON.parse(raw)
  } catch (e) {
    // ignore corrupted storage and fall back to seed data
  }
  return {
    slips: INITIAL_SLIPS,
    receipts: INITIAL_RECEIPTS,
    forms: INITIAL_FORMS,
    timetable: TIMETABLE,
    calendarEvents: CALENDAR_EVENTS,
    accounts: INITIAL_ACCOUNTS,
    notifications: [],
    resultsPublished: false
  }
}

let accountCounter = 9

let receiptCounter = 3000
let formCounter = 4000
let slipCounter = 2000

export function DataStoreProvider({ children }) {
  const [data, setData] = useState(loadInitialState)

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
  }, [data])

  const today = () => new Date().toISOString().slice(0, 10)

  const getStudent = (studentId) => STUDENTS.find((s) => s.id === studentId)

  // ---------- Pipeline A: payment slip -> audit -> finance receipt ----------

  const submitSlip = (studentId, { type, amount, fileName }) => {
    slipCounter += 1
    const slip = {
      id: `SLP-${slipCounter}`,
      studentId,
      semester: SEMESTER,
      type,
      amount: Number(amount) || 0,
      status: 'Pending',
      reason: '',
      fileName: fileName || 'payment_slip.pdf',
      dateSubmitted: today(),
      receiptGenerated: false,
      hold: false,
      financeFlagged: false
    }
    setData((d) => ({ ...d, slips: [slip, ...d.slips] }))
    return slip.id
  }

  const auditReviewSlip = (slipId, decision, reason = '') => {
    setData((d) => ({
      ...d,
      slips: d.slips.map((s) =>
        s.id === slipId
          ? { ...s, status: decision, reason, hold: false, financeFlagged: decision === 'Approved' ? false : s.financeFlagged }
          : s
      )
    }))
  }

  const holdSlip = (slipId, hold) => {
    setData((d) => ({
      ...d,
      slips: d.slips.map((s) => (s.id === slipId ? { ...s, hold } : s))
    }))
  }

  // Finance acts on audit-approved slips: either converts to a receipt
  // (Approved) or rejects the conversion, which flags Audit for re-check.
  const financeReviewSlip = (slipId, decision, reason = '') => {
    if (decision === 'Approved') {
      setData((d) => {
        const slip = d.slips.find((s) => s.id === slipId)
        if (!slip || slip.receiptGenerated) return d
        receiptCounter += 1
        const receipt = {
          id: `RCT-${receiptCounter}`,
          slipId,
          studentId: slip.studentId,
          amount: slip.amount,
          dateIssued: today()
        }
        return {
          ...d,
          receipts: [receipt, ...d.receipts],
          slips: d.slips.map((s) => (s.id === slipId ? { ...s, receiptGenerated: true } : s))
        }
      })
    } else {
      setData((d) => ({
        ...d,
        slips: d.slips.map((s) =>
          s.id === slipId ? { ...s, status: 'Rejected', reason, financeFlagged: true } : s
        )
      }))
    }
  }

  // ---------- Pipeline B: registration form -> 5 signatures ----------

  const submitRegistrationForm = (studentId, courseCodes) => {
    formCounter += 1
    const form = {
      id: `FRM-${formCounter}`,
      studentId,
      semester: SEMESTER,
      fsNo: `STECH-${studentId.slice(-3)}`,
      courseCodes,
      hold: false,
      stages: {
        finance: { status: 'Pending', date: '', reason: '', flagged: false },
        audit: { status: 'Pending', date: '', reason: '', flagged: false },
        hod: { status: 'Pending', date: '', reason: '', flagged: false },
        dean: { status: 'Pending', date: '', reason: '', flagged: false },
        registrar: { status: 'Pending', date: '', reason: '', flagged: false }
      }
    }
    setData((d) => ({ ...d, forms: [form, ...d.forms] }))
    return form.id
  }

  const canSignStage = (form, stageKey) => {
    const idx = STAGE_ORDER.indexOf(stageKey)
    if (idx === 0) return true
    const prevKey = STAGE_ORDER[idx - 1]
    return form.stages[prevKey]?.status === 'Approved'
  }

  const signStage = (formId, stageKey, decision, reason = '') => {
    setData((d) => ({
      ...d,
      forms: d.forms.map((f) => {
        if (f.id !== formId) return f
        const idx = STAGE_ORDER.indexOf(stageKey)
        const updatedStages = {
          ...f.stages,
          [stageKey]: { status: decision, date: today(), reason, flagged: false }
        }
        if (decision === 'Rejected' && idx > 0) {
          const prevKey = STAGE_ORDER[idx - 1]
          updatedStages[prevKey] = {
            ...updatedStages[prevKey],
            flagged: true,
            flagNote: `Flagged by ${STAGE_LABEL[stageKey]}: ${reason}`
          }
        }
        return { ...f, stages: updatedStages }
      })
    }))
  }

  const holdForm = (formId, hold) => {
    setData((d) => ({
      ...d,
      forms: d.forms.map((f) => (f.id === formId ? { ...f, hold } : f))
    }))
  }

  const resetDemoData = () => {
    localStorage.removeItem(STORAGE_KEY)
    setData({
      slips: INITIAL_SLIPS,
      receipts: INITIAL_RECEIPTS,
      forms: INITIAL_FORMS,
      timetable: TIMETABLE,
      calendarEvents: CALENDAR_EVENTS,
      accounts: INITIAL_ACCOUNTS,
      notifications: [],
      resultsPublished: false
    })
  }

  const addTimetableEntry = (entry) => {
    setData((d) => ({ ...d, timetable: [...d.timetable, entry] }))
  }

  const addCalendarEvent = (event) => {
    setData((d) => ({ ...d, calendarEvents: [...d.calendarEvents, event] }))
  }

  // ---------- Admin: account provisioning ----------

  const createAccount = ({ name, idNumber, role }) => {
    accountCounter += 1
    const account = {
      id: `ACC-${String(accountCounter).padStart(3, '0')}`,
      name,
      idNumber,
      role,
      status: 'Active',
      password: DEFAULT_TEMP_PASSWORD,
      mustChangePassword: true
    }
    setData((d) => ({ ...d, accounts: [account, ...d.accounts] }))
    return account
  }

  const toggleAccountStatus = (accountId) => {
    setData((d) => ({
      ...d,
      accounts: d.accounts.map((a) =>
        a.id === accountId ? { ...a, status: a.status === 'Active' ? 'Suspended' : 'Active' } : a
      )
    }))
  }

  const getAccount = (idNumber) =>
    data.accounts.find((a) => a.idNumber.toLowerCase() === String(idNumber).toLowerCase())

  // Called from the forced "Change Password" screen every account hits on
  // first login, since a default temp password set by Admin is never trusted.
  const updateAccountPassword = (idNumber, newPassword) => {
    setData((d) => ({
      ...d,
      accounts: d.accounts.map((a) =>
        a.idNumber.toLowerCase() === String(idNumber).toLowerCase()
          ? { ...a, password: newPassword, mustChangePassword: false }
          : a
      )
    }))
  }

  const sendNotification = (message, audience = 'all') => {
    const notice = { id: Date.now(), audience, message, date: today() }
    setData((d) => ({ ...d, notifications: [notice, ...d.notifications] }))
  }

  // Exams Office calls this once; until then, even fully-cleared students
  // see "registration complete, results not released yet" instead of grades.
  const publishResults = () => {
    setData((d) => ({ ...d, resultsPublished: true }))
    sendNotification('Results are out! Check your grades now.', 'all')
  }

  const value = {
    students: STUDENTS,
    getStudent,
    slips: data.slips,
    receipts: data.receipts,
    forms: data.forms,
    timetable: data.timetable,
    calendarEvents: data.calendarEvents,
    accounts: data.accounts,
    notifications: data.notifications,
    resultsPublished: data.resultsPublished,
    submitSlip,
    auditReviewSlip,
    holdSlip,
    financeReviewSlip,
    submitRegistrationForm,
    signStage,
    canSignStage,
    holdForm,
    addTimetableEntry,
    addCalendarEvent,
    createAccount,
    toggleAccountStatus,
    getAccount,
    updateAccountPassword,
    sendNotification,
    publishResults,
    resetDemoData,
    STAGE_ORDER,
    STAGE_LABEL
  }

  return <DataStoreContext.Provider value={value}>{children}</DataStoreContext.Provider>
}

export function useDataStore() {
  const ctx = useContext(DataStoreContext)
  if (!ctx) throw new Error('useDataStore must be used inside DataStoreProvider')
  return ctx
}
