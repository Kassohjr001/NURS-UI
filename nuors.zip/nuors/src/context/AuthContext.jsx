import { createContext, useContext, useEffect, useState } from 'react'

const AuthContext = createContext(null)
const STORAGE_KEY = 'nuors_auth_v1'

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      return raw ? JSON.parse(raw) : null
    } catch {
      return null
    }
  })

  useEffect(() => {
    if (user) localStorage.setItem(STORAGE_KEY, JSON.stringify(user))
    else localStorage.removeItem(STORAGE_KEY)
  }, [user])

  // Accounts only ever exist because the System Admin created them — there is
  // no self sign-up anywhere in NUORS. `login` is called once the account has
  // already been matched against the accounts list in DataStoreContext.
  const login = (account) => {
    setUser({
      role: account.role,
      name: account.name,
      idNumber: account.idNumber,
      mustChangePassword: Boolean(account.mustChangePassword)
    })
  }

  // Called the moment a forced password reset succeeds, so the rest of the
  // app stops redirecting this session to the Change Password screen.
  const clearMustChangePassword = () => {
    setUser((u) => (u ? { ...u, mustChangePassword: false } : u))
  }

  const logout = () => setUser(null)

  return (
    <AuthContext.Provider value={{ user, login, logout, clearMustChangePassword }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}
