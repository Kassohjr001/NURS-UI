// Seed data for the NUORS demo. Everything here is fictional and only exists
// to make every dashboard feel alive out of the box. The DataStoreContext
// reads this once on first load, then keeps live state in localStorage.

export const SEMESTER = '2025/2026 - Semester 2'

export const STUDENTS = [
  {
    id: 'NU/CSC/2020/001',
    surname: 'Samuel',
    firstName: 'Sahr',
    other: '',
    name: 'Sahr Samuel',
    matNo: 'NU/CSC/2020/001',
    dob: '2000-02-14',
    phone: '076 234 511',
    sex: 'Male',
    nationality: 'Sierra Leonean',
    address: '14 Pottal Street, Bo',
    parentGuardian: 'Mohamed Samuel',
    school: 'School of Technology',
    programme: 'B.Sc. Computer Science',
    major: 'Computer Science',
    minor: 'Mathematics',
    year: 3,
    sponsor: 'SLG',
    accountMode: 'active_registration'
  },
  {
    id: 'NU/CSC/2020/045',
    name: 'John Kamara',
    matNo: 'NU/CSC/2020/045',
    school: 'School of Technology',
    programme: 'B.Sc. Computer Science',
    year: 3,
    sponsor: 'Tuition Waiver',
    accountMode: 'active_registration'
  },
  {
    id: 'NU/CSC/2020/046',
    name: 'Mariama Bah',
    matNo: 'NU/CSC/2020/046',
    school: 'School of Technology',
    programme: 'B.Sc. Computer Science',
    year: 2,
    sponsor: 'Private',
    accountMode: 'active_registration'
  },
  {
    id: 'NU/CSC/2020/047',
    name: 'Ibrahim Sesay',
    matNo: 'NU/CSC/2020/047',
    school: 'School of Technology',
    programme: 'B.Sc. Computer Science',
    year: 1,
    sponsor: 'SLG',
    accountMode: 'active_registration'
  },
  {
    id: 'NU/CSC/2020/048',
    name: 'Aminata Turay',
    matNo: 'NU/CSC/2020/048',
    school: 'School of Technology',
    programme: 'B.Sc. Computer Science',
    year: 2,
    sponsor: 'SLG',
    accountMode: 'active_registration'
  },
  {
    id: 'NU/CSC/2020/049',
    name: 'Mohamed Conteh',
    matNo: 'NU/CSC/2020/049',
    school: 'School of Technology',
    programme: 'B.Sc. Computer Science',
    year: 4,
    sponsor: 'Private',
    accountMode: 'view_only'
  }
]

export const INITIAL_SLIPS = [
  { id: 'SLP-1001', studentId: 'NU/CSC/2020/001', semester: SEMESTER, type: 'Installment 1 (60%)', amount: 6000000, status: 'Approved', reason: '', fileName: 'sahr_slip_inst1.pdf', dateSubmitted: '2026-05-10', receiptGenerated: true, hold: false },
  { id: 'SLP-1002', studentId: 'NU/CSC/2020/045', semester: SEMESTER, type: 'Installment 1 (60%)', amount: 8000000, status: 'Approved', reason: '', fileName: 'kamara_slip.pdf', dateSubmitted: '2026-05-12', receiptGenerated: true, hold: false },
  { id: 'SLP-1003', studentId: 'NU/CSC/2020/046', semester: SEMESTER, type: 'Installment 1 (60%)', amount: 10000000, status: 'Pending', reason: '', fileName: 'bah_slip.pdf', dateSubmitted: '2026-05-12', receiptGenerated: false, hold: false },
  { id: 'SLP-1004', studentId: 'NU/CSC/2020/047', semester: SEMESTER, type: 'Full Payment', amount: 7500000, status: 'Pending', reason: '', fileName: 'sesay_slip.pdf', dateSubmitted: '2026-05-12', receiptGenerated: false, hold: false },
  { id: 'SLP-1005', studentId: 'NU/CSC/2020/048', semester: SEMESTER, type: 'Installment 1 (60%)', amount: 8000000, status: 'Rejected', reason: 'Slip amount does not match bank statement entry for this date.', fileName: 'turay_slip.pdf', dateSubmitted: '2026-05-12', receiptGenerated: false, hold: false },
  { id: 'SLP-1006', studentId: 'NU/CSC/2020/049', semester: SEMESTER, type: 'Installment 2 (40%)', amount: 12000000, status: 'Approved', reason: '', fileName: 'conteh_slip2.pdf', dateSubmitted: '2026-05-13', receiptGenerated: true, hold: false }
]

export const INITIAL_RECEIPTS = [
  { id: 'RCT-2001', slipId: 'SLP-1001', studentId: 'NU/CSC/2020/001', amount: 6000000, dateIssued: '2026-05-11' },
  { id: 'RCT-2002', slipId: 'SLP-1002', studentId: 'NU/CSC/2020/045', amount: 8000000, dateIssued: '2026-05-13' },
  { id: 'RCT-2003', slipId: 'SLP-1006', studentId: 'NU/CSC/2020/049', amount: 12000000, dateIssued: '2026-05-14' }
]

const emptyStage = () => ({ status: 'Pending', date: '', reason: '', flagged: false })

export const INITIAL_FORMS = [
  {
    id: 'FRM-3001',
    studentId: 'NU/CSC/2020/001',
    semester: SEMESTER,
    fsNo: 'STECH-001',
    courseCodes: ['CSC 301', 'CSC 305', 'CSC 312', 'MAT 220'],
    stages: {
      finance: { status: 'Approved', date: '2026-05-15', reason: '', flagged: false },
      audit: { status: 'Approved', date: '2026-05-15', reason: '', flagged: false },
      hod: { status: 'Approved', date: '2026-05-16', reason: '', flagged: false },
      dean: { status: 'Pending', date: '', reason: '', flagged: false },
      registrar: { status: 'Pending', date: '', reason: '', flagged: false }
    }
  },
  {
    id: 'FRM-3002',
    studentId: 'NU/CSC/2020/045',
    semester: SEMESTER,
    fsNo: 'STECH-045',
    courseCodes: ['CSC 301', 'CSC 305', 'CSC 312'],
    stages: {
      finance: { status: 'Approved', date: '2026-05-14', reason: '', flagged: false },
      audit: { status: 'Approved', date: '2026-05-14', reason: '', flagged: false },
      hod: { status: 'Pending', date: '', reason: '', flagged: false },
      dean: emptyStage(),
      registrar: emptyStage()
    }
  },
  {
    id: 'FRM-3003',
    studentId: 'NU/CSC/2020/049',
    semester: SEMESTER,
    fsNo: 'STECH-049',
    courseCodes: ['CSC 401', 'CSC 415', 'CSC 420'],
    stages: {
      finance: { status: 'Approved', date: '2026-05-15', reason: '', flagged: false },
      audit: { status: 'Approved', date: '2026-05-15', reason: '', flagged: false },
      hod: { status: 'Approved', date: '2026-05-16', reason: '', flagged: false },
      dean: { status: 'Approved', date: '2026-05-17', reason: '', flagged: false },
      registrar: { status: 'Approved', date: '2026-05-18', reason: '', flagged: false }
    }
  }
]

export const TIMETABLE = [
  { course: 'CSC 301 — Data Structures', date: '2026-07-06', time: '9:00 AM', venue: 'Hall A' },
  { course: 'CSC 305 — Operating Systems', date: '2026-07-08', time: '1:00 PM', venue: 'Hall B' },
  { course: 'CSC 312 — Database Systems', date: '2026-07-10', time: '9:00 AM', venue: 'Hall A' },
  { course: 'MAT 220 — Linear Algebra', date: '2026-07-12', time: '11:00 AM', venue: 'Hall C' }
]

export const CALENDAR_EVENTS = [
  { title: 'Second Semester registration opens', date: '2026-05-05' },
  { title: 'Exam timetable released', date: '2026-06-20' },
  { title: 'Second semester exams begin', date: '2026-07-06' },
  { title: 'Results publication', date: '2026-08-01' }
]

export const RESULTS = {
  'NU/CSC/2020/001': [
    { course: 'CSC 301', grade: 'A', credits: 3 },
    { course: 'CSC 305', grade: 'B+', credits: 3 },
    { course: 'CSC 312', grade: 'A-', credits: 4 },
    { course: 'MAT 220', grade: 'B', credits: 3 }
  ]
}

export const NOTIFICATIONS = [
  { id: 1, audience: 'NU/CSC/2020/001', message: 'Exam timetable for Second Semester is out. Please check your timetable.', date: '2026-06-10' },
  { id: 2, audience: 'NU/CSC/2020/001', message: 'Your registration form is awaiting Dean approval.', date: '2026-06-12' },
  { id: 3, audience: 'all', message: 'Academic calendar for 2025/2026 has been updated.', date: '2026-05-20' }
]

export const DEPARTMENTS = [
  { name: 'Computer Science', students: 620, resultsPublished: true },
  { name: 'Mathematics', students: 300, resultsPublished: true },
  { name: 'Physics', students: 390, resultsPublished: false },
  { name: 'Chemistry', students: 280, resultsPublished: false },
  { name: 'Biology', students: 300, resultsPublished: false }
]

export const DEFAULT_TEMP_PASSWORD = 'Welcome123'

export const INITIAL_ACCOUNTS = [
  { id: 'ACC-001', name: 'Sahr Samuel', idNumber: 'NU/CSC/2020/001', role: 'student', status: 'Active', password: DEFAULT_TEMP_PASSWORD, mustChangePassword: true },
  { id: 'ACC-002', name: 'Fatmata Koroma', idNumber: 'STAFF-AUD-01', role: 'audit', status: 'Active', password: DEFAULT_TEMP_PASSWORD, mustChangePassword: true },
  { id: 'ACC-003', name: 'Abdul Sheriff', idNumber: 'STAFF-FIN-01', role: 'finance', status: 'Active', password: DEFAULT_TEMP_PASSWORD, mustChangePassword: true },
  { id: 'ACC-004', name: 'Hawa Jalloh', idNumber: 'STAFF-EXM-01', role: 'exams', status: 'Active', password: DEFAULT_TEMP_PASSWORD, mustChangePassword: true },
  { id: 'ACC-005', name: 'Dr. Joseph Kallon', idNumber: 'STAFF-HOD-01', role: 'hod', status: 'Active', password: DEFAULT_TEMP_PASSWORD, mustChangePassword: true },
  { id: 'ACC-006', name: 'Prof. Adama Sesay', idNumber: 'STAFF-DEAN-01', role: 'dean', status: 'Active', password: DEFAULT_TEMP_PASSWORD, mustChangePassword: true },
  { id: 'ACC-007', name: 'Memuna Kargbo', idNumber: 'STAFF-REG-01', role: 'registrar', status: 'Active', password: DEFAULT_TEMP_PASSWORD, mustChangePassword: true },
  { id: 'ACC-008', name: 'System Administrator', idNumber: 'STAFF-ADM-01', role: 'admin', status: 'Active', password: DEFAULT_TEMP_PASSWORD, mustChangePassword: true },
  { id: 'ACC-009', name: 'Prof. Ibrahim Bangura', idNumber: 'STAFF-VC-01', role: 'vc', status: 'Active', password: DEFAULT_TEMP_PASSWORD, mustChangePassword: true },
  { id: 'ACC-010', name: 'Mohamed Conteh', idNumber: 'NU/CSC/2020/049', role: 'student', status: 'Active', password: DEFAULT_TEMP_PASSWORD, mustChangePassword: true }
]

export const COURSES = [
  { code: 'CSC 301', title: 'Data Structures & Algorithms', credits: 3 },
  { code: 'CSC 305', title: 'Operating Systems', credits: 3 },
  { code: 'CSC 308', title: 'Software Engineering', credits: 3 },
  { code: 'CSC 312', title: 'Database Systems', credits: 4 },
  { code: 'CSC 320', title: 'Computer Networks', credits: 3 },
  { code: 'MAT 220', title: 'Linear Algebra', credits: 3 }
]
