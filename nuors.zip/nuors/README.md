# NUORS — Njala University Online Registration System

A frontend prototype of the full registration and fee-clearance pipeline described in the project documentation:
payment slip → Audit verification → Finance receipt → student course registration → Finance/Audit/HOD/Dean/Registrar
signatures → distribution. Nine independent, route-isolated dashboards share one in-memory "live" data store so
actions taken in one office are immediately visible in the others — no backend required for the demo.

## Run it

```bash
pnpm install
pnpm dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

## Single sign-in, role-based redirect, forced password change

There is **one login page** at `/login`. Every account — student or staff — is created by the System Admin
(see Admin → User Management) and carries a role. Signing in looks up the ID you enter against the accounts list
and checks the password for real.

Every new account starts with the temporary password `Welcome123` and `mustChangePassword: true`. The **first**
time that account signs in, the app redirects straight to `/change-password` before it can reach any dashboard —
the new password must be at least 8 characters with an uppercase letter, a lowercase letter, and a number, and
can't be the temporary one. Once set, that account signs in normally from then on.

**Quick demo logins** (one-tap buttons on the login screen skip the password and the forced reset, for fast
demoing across roles):

| Role | Login ID | Lands on |
|---|---|---|
| Student | `NU/CSC/2020/001` | `/` |
| Audit | `STAFF-AUD-01` | `/audit` |
| Finance | `STAFF-FIN-01` | `/finance` |
| Exams Office | `STAFF-EXM-01` | `/exams` |
| HOD | `STAFF-HOD-01` | `/hod` |
| Dean | `STAFF-DEAN-01` | `/dean` |
| Department Registrar | `STAFF-REG-01` | `/registrar` |
| System Admin | `STAFF-ADM-01` | `/admin` |
| Vice Chancellor | `STAFF-VC-01` | `/vc` |

To see the forced password-change flow itself, type one of the IDs above into the manual sign-in form with
password `Welcome123` instead of using the quick-login buttons.

## What's actually wired up (not just static UI)

- **Payment pipeline**: submit a slip as the Student → it appears in Audit's Pending Reviews → Approve/Reject it →
  approved slips move to Finance's queue → Finance generates the receipt → it shows up in the Student's Receipts tab.
- **Registration pipeline**: once a receipt exists, the Student can select courses and submit the registration
  form → it routes through Finance → Audit → HOD → Dean → Registrar in that order (a stage can't be approved until
  the one before it is). Rejecting a stage automatically flags the previous stage for re-verification.
- **Registration workflow tracker**: both the Student's main Dashboard and their Registration Forms tab show a
  live 5-stage pipeline visual — done / currently-with / flagged / rejected / not-yet-reached — so the student
  always knows exactly which office their form is sitting with and why.
- **Hold / cancellation control**: Audit, Finance, HOD, Dean, and Registrar can each put a pending item on Hold
  instead of approving or rejecting it. While on hold, it can't move forward or backward (no Approve/Reject
  buttons show) until that same office clicks Resume. The student sees the same "Hold" status on their own
  Payments and Registration Forms tabs.
- **Reference-only ("exceptional") student accounts**: an account with `accountMode: 'view_only'` in
  `src/data/mockData.js` only ever sees Results, Timetable, Academic Calendar, and Support — no Payments, no
  Course Registration, no Profile. Log in as `NU/CSC/2020/049` (Mohamed Conteh, password `Welcome123`) to see this.
- **Results are genuinely gated twice**: a student only sees grades once (1) their registration form is fully
  signed off by Registrar, AND (2) the Exams Office has actually clicked "Publish Results" for the semester —
  being fully cleared alone isn't enough, matching how real exam boards withhold results until release day.
- **PDF generation**: the Student's Registration Forms tab can download a real PDF (via `jspdf`) reflecting the
  live signature status of that form.
- **Live notifications & timetable**: anything Admin broadcasts or Exams Office publishes to the timetable/calendar
  shows up immediately on the Student dashboard.
- **Account creation**: Admin's User Management page actually creates new accounts that can then log in.
- **Support chatbot**: floating assistant on the Student dashboard answers questions using that student's real,
  live status rather than canned text.

All of this is held in React state and mirrored to `localStorage`, so it survives a page refresh but resets if you
clear site data or click **Reset Demo Data** under Admin → Settings.

## Project structure

```
src/
  components/
    student/    audit/    finance/    exams/    hod/    dean/    registrar/    admin/    vc/
      XDashboard.jsx     -> thin composer: state, actions, nav config, then picks a section to render
      sections/          -> one file per tab (Overview, Pending Reviews, Reports, ...)
      sections/columns.jsx (or helpers.jsx) -> shared table-column builders for that dashboard, where needed
    auth/         -> LoginPage.jsx, ChangePasswordPage.jsx
    layout/       -> Sidebar, Topbar, DashboardShell (shared chrome, themed per role)
    common/       -> StatCard, Badge, DataTable, Charts, ProgressStepper, WorkflowTracker, ChatbotWidget, ProtectedRoute
  context/
    AuthContext.jsx        -> who's logged in, including the forced-password-change flag
    DataStoreContext.jsx   -> the shared pipeline state + every action (approve/reject/hold/sign/create account...)
  data/mockData.js         -> seed data
  utils/generateFormPdf.js -> client-side PDF export
  theme.js                 -> per-role color identity and routes
```

Every one of the 9 dashboards follows the exact same internal structure as Student: a small top-level
`XDashboard.jsx` that holds state and wires up actions, and a `sections/` folder with one file per tab. That
means editing, say, just the Reports tab on the Finance dashboard means opening `finance/sections/Reports.jsx` —
nothing else in that dashboard needs to be touched, and it's safe for two people to edit two different tabs of
the same dashboard without colliding in git.

Each role's `XDashboard.jsx` is the only file mounted at that role's route (`/audit`, `/finance`, etc.) — they all
render into the same `DashboardShell` layout component but are otherwise fully independent pages with their own
sidebar nav, stat cards, tables, and charts.

## Known simplifications (clearly marked for a hackathon build)

- No backend — accounts, passwords, and pipeline state all live in `localStorage` via React context.
- Reject reasons are captured via `window.prompt` rather than a custom modal.
- Bank statement reconciliation, real file uploads, and email/SMS delivery are represented as UI only.
- New student accounts created via Admin won't have full profile data unless the ID matches one of the seeded
  students in `src/data/mockData.js` — extend that file to add more.
